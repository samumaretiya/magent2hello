<?php

namespace Magestore\OneStepCheckout\Model;


class Order extends \Magento\Sales\Model\Order
{
	public function getOrderShipDueDate(){
		if($this->getShipDueDate()!="") : 
			//return date('D m YY',strtotime($this->getShipDueDate());
			//return date('m d Y', strtotime($this->getShipDueDate()));			
		return $this->getShipDueDate();
		else:
			return 'Not Applicable';
		endif;
	}
	
	public function getOrderShipPoNumber(){
		if($this->getShipPoNumber()!="") : 
			return $this->getShipPoNumber();
		else:
			return 'Not Applicable';
		endif;
	}
	
	public function getOrderShipComment(){
		if($this->getShipComment()!="") : 
			return $this->getShipComment();
		else:
			return 'Not Applicable';
		endif;
	}
}  
