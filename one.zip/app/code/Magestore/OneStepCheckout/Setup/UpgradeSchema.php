<?php

/**
 * *
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Magestore\OneStepCheckout\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '2.0.0', '<')) {
            $setup->getConnection()->addColumn(
                $setup->getTable('onestepcheckout_delivery'),
                'osc_security_code',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT
            );

            $setup->getConnection()->addColumn(
                $setup->getTable('sales_creditmemo'),
                'onestepcheckout_giftwrap_amount',
                'DECIMAL(12,4)'
            );

            $setup->getConnection()->addColumn(
                $setup->getTable('sales_creditmemo'),
                'onestepcheckout_base_giftwrap_amount',
                'DECIMAL(12,4)'
            );
        }

		if (version_compare($context->getVersion(), '3.0.0') < 0) {
            $tableName = $setup->getTable('sales_order');
            if ($setup->getConnection()->isTableExists($tableName) == true) {
           	   $setup->getConnection()->addColumn(
													$tableName,
													'ship_due_date',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														'comment' => 'Ship Due Date',
				   										'255',
													]
													
												  );
				
				$setup->getConnection()->addColumn(
													$tableName,
													'ship_po_number',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														'comment' => 'Ship PO Number',
														'255',
													]
													
												  );
				$setup->getConnection()->addColumn(
													$tableName,
													'ship_comment',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														'comment' => 'Ship Comment',
														'255',
													]
													
											  );
            }
			 
			$tableName = $setup->getTable('quote');

			if ($setup->getConnection()->isTableExists($tableName) == true) {
				$setup->getConnection()->addColumn(
													$tableName,
													'ship_due_date',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														'comment' => 'Ship Due Date',
														'255',
													]
													
												  );
				
				$setup->getConnection()->addColumn(
													$tableName,
													'ship_po_number',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														 
														'comment' => 'Ship PO Number',
														'255',
													]
													
												  );
				
				
				$setup->getConnection()->addColumn(
													$tableName,
													'ship_comment',
													[
														'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
														'nullable' => true,
														'comment' => 'Ship Comment',
														'255',
					
													]
													
											  );
          }
          $setup->endSetup();
       }
        $installer->endSetup();
    }
}
