<?php

namespace Dcs\Testimonials\Block; 

class Testimonials extends \Magento\Framework\View\Element\Template 
{

	protected $_testimonials;    
  
    protected $_testimonialsHelper;


	protected function _prepareLayout()
    {
       parent::_prepareLayout();
    	$this->pageConfig->getTitle()->set(__('Testimonials'));


	    if ($this->getTestimonials()) {
	        $pager = $this->getLayout()->createBlock(
	            'Magento\Theme\Block\Html\Pager',
	            'fme.news.pager'
	        )->setAvailableLimit($this->getAvailableLimit())->setShowPerPage(true)->setCollection(
	            $this->getTestimonials()
	        );
	        $this->setChild('pager', $pager);
	        $this->getTestimonials()->load();
	    }
    	return $this;
    }


    public function __construct(
    	\Magento\Catalog\Block\Product\Context $context,
    	\Dcs\Testimonials\Model\Testimonials $testimonials, 
        \Dcs\Testimonials\Helper\Data $testimonialsHelper,
    	array $data = []) 
    {
        parent::__construct($context, $data); 
         $this->_testimonials = $testimonials;  
        $this->_testimonialsHelper = $testimonialsHelper;
    }

    /*check module is enabled or not for frontend*/
    public function isEnabled()
    {
         return $this->_testimonialsHelper->isEnabled();
    }

    /*get collection with pagination filter data*/
    public function getTestimonials()
    {
      //get values of current page
        $page=($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
    //get values of current limit
        $pageSize=($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : $this->getDefaultPageSize();


        $testimonialsCollection = $this->_testimonials->getCollection();
        $testimonialsCollection->addFieldToFilter('status',\Dcs\Testimonials\Model\Status::STATUS_ENABLED);
        $testimonialsCollection->setOrder('rank','ASC');
        $testimonialsCollection->setPageSize($pageSize);
        $testimonialsCollection->setCurPage($page);
        return $testimonialsCollection;
    }

    /*This is use for check how many records are save in db*/

    public function getAllTestimonialCount(){
    	$testimonialsCollection = $this->_testimonials->getCollection();
        $testimonialsCollection->addFieldToSelect('*')
        						->addFieldToFilter('status',\Dcs\Testimonials\Model\Status::STATUS_ENABLED)
        						->setOrder('rank','ASC');
        return count($testimonialsCollection);
    }

    /* show per page recors in frontend*/
    public function getDefaultPageSize(){
    	return $this->_testimonialsHelper->getPerPageRecords();
    }

    /*make toolbar limiter here*/
    public function getAvailableLimit(){
    	$perPageRecords = $this->getDefaultPageSize();
    	return array(
    		$perPageRecords => $perPageRecords,
    		$perPageRecords+$perPageRecords => $perPageRecords+$perPageRecords,
    		$perPageRecords+($perPageRecords*2) =>$perPageRecords+($perPageRecords*2),
    		$perPageRecords+($perPageRecords*3) =>$perPageRecords+($perPageRecords*3)
    			);
    }

    public function getPagerHtml()
	{
		$allCount = $this->getAllTestimonialCount();
		$defaultCount = $this->getDefaultPageSize();
		if($allCount > $defaultCount){
			return $this->getChildHtml('pager');
		}
	    
	}
	 
}