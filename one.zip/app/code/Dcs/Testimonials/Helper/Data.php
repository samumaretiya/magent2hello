<?php 
namespace Dcs\Testimonials\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{ 
     
    const XML_PATH_ENABLED = 'dcs_testimonials/general/enable';

    const XML_PATH_PER_PAGE_RECORD = 'dcs_testimonials/general/per_page';

    const DEFAULT_RECORDS = 10;
    
 
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }  

    public function getPerPageRecords()
    {
        $recordPerPage = $this->scopeConfig->getValue(
            self::XML_PATH_PER_PAGE_RECORD,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        if($recordPerPage && $recordPerPage != 0){
            return $recordPerPage;
        }
        return self::DEFAULT_RECORDS;
    }  
}