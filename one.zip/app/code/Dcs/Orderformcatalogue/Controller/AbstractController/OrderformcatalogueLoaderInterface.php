<?php

namespace Dcs\Orderformcatalogue\Controller\AbstractController;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;

interface OrderformcatalogueLoaderInterface
{
    /**
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return \Dcs\Orderformcatalogue\Model\Orderformcatalogue
     */
    public function load(RequestInterface $request, ResponseInterface $response);
}
