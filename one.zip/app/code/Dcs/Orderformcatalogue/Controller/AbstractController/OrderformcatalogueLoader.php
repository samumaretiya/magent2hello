<?php

namespace Dcs\Orderformcatalogue\Controller\AbstractController;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Registry;

class OrderformcatalogueLoader implements OrderformcatalogueLoaderInterface
{
    /**
     * @var \Dcs\Orderformcatalogue\Model\OrderformcatalogueFactory
     */
    protected $orderformcatalogueFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $url;

    /**
     * @param \Dcs\Orderformcatalogue\Model\OrderformcatalogueFactory $orderformcatalogueFactory
     * @param OrderViewAuthorizationInterface $orderAuthorization
     * @param Registry $registry
     * @param \Magento\Framework\UrlInterface $url
     */
    public function __construct(
        \Dcs\Orderformcatalogue\Model\OrderformcatalogueFactory $orderformcatalogueFactory,
        Registry $registry,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->orderformcatalogueFactory = $orderformcatalogueFactory;
        $this->registry = $registry;
        $this->url = $url;
    }

    /**
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return bool
     */
    public function load(RequestInterface $request, ResponseInterface $response)
    {
        $id = (int)$request->getParam('id');
        if (!$id) {
            $request->initForward();
            $request->setActionName('noroute');
            $request->setDispatched(false);
            return false;
        }

        $orderformcatalogue = $this->orderformcatalogueFactory->create()->load($id);
        $this->registry->register('current_orderformcatalogue', $orderformcatalogue);
        return true;
    }
}
