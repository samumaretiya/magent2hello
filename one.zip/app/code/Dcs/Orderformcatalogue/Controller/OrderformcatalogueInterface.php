<?php

namespace Dcs\Orderformcatalogue\Controller;

use Magento\Framework\App\ActionInterface;

interface OrderformcatalogueInterface extends ActionInterface
{
}
