<?php
namespace Dcs\Orderformcatalogue\Controller\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
//use Dcs\Orderformcatalogue\Controller\AbstractAction;

class Post extends \Magento\Framework\App\Action\Action	
{
	 const XML_PATH_CUSTOMER_EMAIL  = 'orderformcatalogue/view/email_template';
	 const XML_PATH_ADMIN_EMAIL  = 'orderformcatalogue/view/admin_email'; 
	 const XML_PATH_EMAIL_SENDER = 'contact/email/sender_email_identity';
	
	public function __construct(
        Context $context,
		\Magento\Framework\Controller\ResultFactory $resultFactory,
		\Magento\Framework\Translate\Inline\StateInterface $StateInterface,
		\Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
		\Dcs\Orderformcatalogue\Helper\Data $helperOrderformcatalogue,
		\Dcs\Orderformcatalogue\Model\Orderformcatalogue $_orderformcatalogueModel,
		\Dcs\Orderformcatalogue\Helper\Email $emailHelper
		
    ){
        parent::__construct($context);		
		$this->resultFactory = $resultFactory;
		$this->StateInterface = $StateInterface;
		$this->StoreManagerInterface = $StoreManagerInterface;
		$this->_orderformcatalogueModel = $_orderformcatalogueModel;  
		$this->helperOrderformcatalogue = $helperOrderformcatalogue;
		$this->EmailHelper = $emailHelper;
    }
	public function execute()
	{
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$post 			= $this->getRequest()->getPostValue();
		/*echo '<pre>';
			print_r($post);
		echo '</pre>';
		exit;*/
		
		$name 		= $this->getRequest()->getPost('name');
		$position 	= $this->getRequest()->getPost('position');		
		$company	= $this->getRequest()->getPost('company');
		$phone 		= $this->getRequest()->getPost('phone');
		$fax 		= $this->getRequest()->getPost('fax');
		$email 		= $this->getRequest()->getPost('email'); 		
		$address 	= $this->getRequest()->getPost('address');
		//$suburb 	= $this->getRequest()->getPost('suburb');		
		$state 		= $this->getRequest()->getPost('state');
		$postcode 		= $this->getRequest()->getPost('postcode');
		$comment 	= $this->getRequest()->getPost('comment');	 
		
		if (!$post) {
			$this->_redirect('*/*/');
			return;
		}		 
		try {
			
			//$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE; 
			$error = false;
			
			$this->_orderformcatalogueModel->setData('name',$name);
			$this->_orderformcatalogueModel->setData('position',$position);
			$this->_orderformcatalogueModel->setData('company',$company);
			$this->_orderformcatalogueModel->setData('phone',$phone);
			$this->_orderformcatalogueModel->setData('fax',$fax);
			$this->_orderformcatalogueModel->setData('email',$email);			
			$this->_orderformcatalogueModel->setData('address',$address);
			//$this->_orderformcatalogueModel->setData('suburb',$suburb);
			$this->_orderformcatalogueModel->setData('postcode',$postcode);
			$this->_orderformcatalogueModel->setData('state',$state);			
			$this->_orderformcatalogueModel->setData('comment',$comment);			
			
			if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
				$error = true;
			}			
			if (!\Zend_Validate::is(trim($post['email']), 'EmailAddress')) {
				$error = true;
			}
			if($post['g-recaptcha-response'] == ''){
				$error = true;
			} 
			if ($error) {
				throw new \Exception();
			}

			try { 
				$postObject = new \Magento\Framework\DataObject();
				$postObject->setData($post);
				/****************************************************************/
				//$helper = $this->_objectManager->get('Dcs\Orderformcatalogue\Helper\Data');
				
				/* Receiver Detail  */
				$receiveremail = $this->helperOrderformcatalogue->Recipientemail();
				
				$receiverInfo = [
					'name' => 'Order Free Catalogue',
					'email' => $receiveremail,
				];

				$sendername = $this->helperOrderformcatalogue->GeneralName();
				$senderemail = $this->helperOrderformcatalogue->GeneralEmail();
				
				$senderInfo = [
					'name' => $sendername,
					'email' => $senderemail,
				];				 
				
				/****************** Email Send Code start *****************************************************/			
				$customerInfo = [
					'name' =>   $name,
					'email' => $email,
				];
				
				/*Email to admin start*/
					$this->EmailHelper->orderFormMailSendMethod($postObject,$senderInfo,$receiverInfo); 	
				/*Email to admin end*/
				
				/*Email to customer start*/
					$this->EmailHelper->orderFormMailSendMethodToCustomer($postObject,$senderInfo,$customerInfo);	
				/*Email to customer end*/				
				/****************** End Send Code start *****************************************************/
				
				// Data base store data
				$this->_orderformcatalogueModel->save();
				$this->helperOrderformcatalogue->setMessage(true,__('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.'));
				//$this->messageManager->addSuccess(__('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.'));
			} catch (\Exception $e) {
				$this->helperOrderformcatalogue->setMessage(false,__('We can\'t process your request right now. Sorry, that\'s all we know.'));
				//$this->messageManager->addError(__('We can\'t process your request right now. Sorry, that\'s all we know.'));
			}

		} catch (\Exception $e) {
			$this->helperOrderformcatalogue->setMessage(false,__('We can\'t process your request right now. Sorry, that\'s all we know.'));
			//$this->messageManager->addError(__('We can\'t process your request right now. Sorry, that\'s all we know.'));
		} 		
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
