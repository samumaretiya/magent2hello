<?php

namespace Dcs\Orderformcatalogue\Model\ResourceModel;

/**
 * Orderformcatalogue Resource Model
 */
class Orderformcatalogue extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('dcs_orderformcatalogue', 'orderformcatalogue_id');
    }
}
