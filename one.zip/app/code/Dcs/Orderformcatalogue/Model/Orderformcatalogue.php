<?php

namespace Dcs\Orderformcatalogue\Model;

/**
 * Orderformcatalogue Model
 *
 * @method \Dcs\Orderformcatalogue\Model\Resource\Page _getResource()
 * @method \Dcs\Orderformcatalogue\Model\Resource\Page getResource()
 */
class Orderformcatalogue extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue');
    }

}
