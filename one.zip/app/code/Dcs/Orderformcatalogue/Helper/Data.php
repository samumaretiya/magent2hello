<?php

/**
 * Orderformcatalogue data helper
 */
namespace Dcs\Orderformcatalogue\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Path to store config where count of orderformcatalogue posts per page is stored
     *
     * @var string
     */
    
	const XML_PATH_ENABLE 	  = "orderformcatalogue/view/enabled";
	const XML_PATH_SITEKEY   = "contactus/view/recapcha_sitekey";
	const XML_PATH_SECRETKEY = "contactus/view/recapcha_secretkey";
	const XML_PATH_RECIPIENT_EMAIL = "orderformcatalogue/view/recipient_email";
	const XML_PATH_GENERAL_NAME = 'trans_email/ident_general/name';
    const XML_PATH_GENERAL_EMAIL = 'trans_email/ident_general/email';
	
    protected $httpFactory;
    protected $_storeManager;	
	protected $customerSession;	
	protected $inlineTranslation;
    protected $formKey;
    
    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,    
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\HTTP\Adapter\FileTransferFactory $httpFactory,        
        \Magento\Store\Model\StoreManagerInterface $storeManager,		
        \Magento\Customer\Model\Session $customerSession,
		\Magento\Framework\Translate\Inline\StateInterface $inlineTranslation        
    ) {
        $this->_scopeConfig = $scopeConfig;        
        $this->formKey = $formKey;        
        $this->httpFactory = $httpFactory;        
        $this->_storeManager = $storeManager;        
		$this->_customerSession = $customerSession;
		$this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }
    
   
    public function getFormKey()
	{
		return $this->formKey->getFormKey();
	}
    
	public function isEnabled()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->isSetFlag(self::XML_PATH_ENABLE,$storeScope);
    }
	public function Sitekey()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_SITEKEY,$storeScope);
    }
	public function Secretkey()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_SECRETKEY,$storeScope);
    }
	public function Recipientemail()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_RECIPIENT_EMAIL,$storeScope);
    }
	public function GeneralName()
	{
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
 		return $this->scopeConfig->getValue(self::XML_PATH_GENERAL_NAME, $storeScope);
    }
	
	public function GeneralEmail()
	{
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
 		return $this->scopeConfig->getValue(self::XML_PATH_GENERAL_EMAIL, $storeScope);
    }
	
	public function isCustomerLoggedIn()
	{
		 return $this->_customerSession;
	}
	
	public function CustomerEmail()
    {	
		return trim($this->_customerSession->getCustomer()->getEmail());		
    }	
	
	public function getBaseUrl()
    { 
        $storeId = $this->_storeManager->getDefaultStoreView()->getStoreId();
    	$url = $this->_storeManager->getStore($storeId)->getUrl();
		return $url;
    }
    public function setMessage($status,$message)
	{
		$this->_customerSession->setContactMessageStatus($status);
		 $this->_customerSession->setContactMessage($message);
	}
}
