<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Dcs\Orderformcatalogue\Block\Html;

/**
 * Logo page header block
 */
class Logo extends \Magento\Theme\Block\Html\Header\Logo
{
    public function getLogoHeaderUrl(){ 
        $logoUrl12 = $this->_urlBuilder
                ->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) . "logo/stores/sticky-logo.png"; 
        return $logoUrl12;
    } 
}
