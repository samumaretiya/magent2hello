<?php

namespace Dcs\Orderformcatalogue\Block;

/**
 * Orderformcatalogue content block
 */
class Orderformcatalogue extends \Magento\Framework\View\Element\Template
{
    /**
     * Orderformcatalogue collection
     *
     * @var Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue\Collection
     */
    protected $_orderformcatalogueCollection = null;
    
    /**
     * Orderformcatalogue factory
     *
     * @var \Dcs\Orderformcatalogue\Model\OrderformcatalogueFactory
     */
    protected $_orderformcatalogueCollectionFactory;
    
    /** @var \Dcs\Orderformcatalogue\Helper\Data */
    protected $_dataHelper;
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue\CollectionFactory $orderformcatalogueCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue\CollectionFactory $orderformcatalogueCollectionFactory,
        \Dcs\Orderformcatalogue\Helper\Data $dataHelper,
		\Magento\Directory\Model\Region $regiondata,
        array $data = []
    ) {
        $this->_orderformcatalogueCollectionFactory = $orderformcatalogueCollectionFactory;
        $this->_dataHelper = $dataHelper;
		$this->regiondata = $regiondata;
        parent::__construct(
            $context,
            $data
        );
    }
	 public function isEnabledModule()
    {
		 return $this->_dataHelper->isEnabled();
    }
    
	public function regionList()
    {
		$region_list = $this->regiondata->getCollection()->addFieldToFilter('country_id','AU');
		return $region_list;		
    }
	
    
    /**
     * Retrieve orderformcatalogue collection
     *
     * @return Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue\Collection
     */
    protected function _getCollection()
    {
        $collection = $this->_orderformcatalogueCollectionFactory->create();
        return $collection;
    }
    
    /**
     * Retrieve prepared orderformcatalogue collection
     *
     * @return Dcs\Orderformcatalogue\Model\ResourceModel\Orderformcatalogue\Collection
     */
    public function getCollection()
    {
        if (is_null($this->_orderformcatalogueCollection)) {
            $this->_orderformcatalogueCollection = $this->_getCollection();
            $this->_orderformcatalogueCollection->setCurPage($this->getCurrentPage());
            $this->_orderformcatalogueCollection->setPageSize($this->_dataHelper->getOrderformcataloguePerPage());
            $this->_orderformcatalogueCollection->setOrder('published_at','asc');
        }

        return $this->_orderformcatalogueCollection;
    }
    
    /**
     * Fetch the current page for the orderformcatalogue list
     *
     * @return int
     */
    public function getCurrentPage()
    {
        return $this->getData('current_page') ? $this->getData('current_page') : 1;
    }
    
    /**
     * Return URL to item's view page
     *
     * @param Dcs\Orderformcatalogue\Model\Orderformcatalogue $orderformcatalogueItem
     * @return string
     */
    public function getItemUrl($orderformcatalogueItem)
    {
        return $this->getUrl('*/*/view', array('id' => $orderformcatalogueItem->getId()));
    }
    
    /**
     * Return URL for resized Orderformcatalogue Item image
     *
     * @param Dcs\Orderformcatalogue\Model\Orderformcatalogue $item
     * @param integer $width
     * @return string|false
     */
    public function getImageUrl($item, $width)
    {
        return $this->_dataHelper->resize($item, $width);
    }
    
    /**
     * Get a pager
     *
     * @return string|null
     */
    public function getPager()
    {
        $pager = $this->getChildBlock('orderformcatalogue_list_pager');
        if ($pager instanceof \Magento\Framework\Object) {
            $orderformcataloguePerPage = $this->_dataHelper->getOrderformcataloguePerPage();

            $pager->setAvailableLimit([$orderformcataloguePerPage => $orderformcataloguePerPage]);
            $pager->setTotalNum($this->getCollection()->getSize());
            $pager->setCollection($this->getCollection());
            $pager->setShowPerPage(TRUE);
            $pager->setFrameLength(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            )->setJump(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame_skip',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            );

            return $pager->toHtml();
        }

        return NULL;
    }
}
