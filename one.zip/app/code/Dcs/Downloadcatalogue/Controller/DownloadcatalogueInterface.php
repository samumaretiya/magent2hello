<?php

namespace Dcs\Downloadcatalogue\Controller;

use Magento\Framework\App\ActionInterface;

interface DownloadcatalogueInterface extends ActionInterface
{
}
