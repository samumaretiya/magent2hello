var config = {
	paths: { 
		'dcs/downloadcatalogue': 'Dcs_Downloadcatalogue/js/owl.carousel.min',			 
	},
	shim: {		 
		'dcs/downloadcatalogue': {
			deps: ['jquery']
		},		 	 
	}
};
