<?php

namespace Dcs\Updateaccount\Block\Customer;

class Link extends \Magento\Framework\View\Element\Html\Link\Current
{
    protected $_customerSession;
    
    protected $exocustomerHelper;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\DefaultPathInterface $defaultPath,
        \Myob\Exocustomers\Helper\Data $exocustomerHelper,
        \Magento\Customer\Model\Session $customerSession,
        array $data = []
     ) {
         $this->_exocustomerHelper = $exocustomerHelper;
         $this->_customerSession = $customerSession;
         parent::__construct($context, $defaultPath, $data);
     }

    protected function _toHtml()
    {
       if($this->_exocustomerHelper->isExocustomers()) {
                return parent::_toHtml(); //Return link html
            } else {
                return; //Return null
            }
        return;
    }
}
?>
