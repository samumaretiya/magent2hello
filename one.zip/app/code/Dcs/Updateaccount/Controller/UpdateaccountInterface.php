<?php

namespace Dcs\Updateaccount\Controller;

use Magento\Framework\App\ActionInterface;

interface UpdateaccountInterface extends ActionInterface
{
}
