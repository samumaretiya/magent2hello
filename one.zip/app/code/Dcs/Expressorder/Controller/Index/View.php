<?php
namespace Dcs\Expressorder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Dcs\Expressorder\Helper\Data;

use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Model\Session;
use Magento\Framework\App\ResourceConnection;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Search\Model\QueryFactory;

class View extends Action
{
    /** @var PageFactory */
    protected $pageFactory;
	
    /** @var  \Magento\Catalog\Model\ResourceModel\Product\Collection */
  //  protected $productCollection;
    protected $helper;
	
	/**
     * Catalog session
     *
     * @var Session
     */
    protected $_catalogSession;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var QueryFactory
     */
    private $_queryFactory;

    /**
     * Catalog Layer Resolver
     *
     * @var Resolver
     */
    private $layerResolver;

    public function __construct(
        Context $context,
        PageFactory $pageFactory,        
		Data $helper,
		
		Session $catalogSession,
        StoreManagerInterface $storeManager,
        QueryFactory $queryFactory,
        Resolver $layerResolver
        
    )
    {
        $this->pageFactory = $pageFactory;
        $this->helper = $helper;
		
		$this->_storeManager = $storeManager;
        $this->_catalogSession = $catalogSession;
        $this->_queryFactory = $queryFactory;
        $this->layerResolver = $layerResolver;
        parent::__construct($context);
    }

    public function execute()
    {
		if($this->helper->isEnabled()){
			$result = $this->pageFactory->create();		   
            return $result; 
        } else {
			$this->_redirect('noRoute');
			return false;
		}
		/*if($this->helper->isEnabled()) {
			$this->layerResolver->create(Resolver::CATALOG_LAYER_SEARCH);
			@var $query \Magento\Search\Model\Query
			$query = $this->_queryFactory->get();
			$query->setStoreId($this->_storeManager->getStore()->getId());									
			$item_code = $this->getRequest()->getPostValue('item_code');			
			$description = $this->getRequest()->getPostValue('description');
			
			if($item_code && $description) {
				$search_str = $item_code.','.$description;
			} else if($item_code) {
				$search_str = $item_code;
			} else if($description) {
				$search_str = $description;
			} else {
				$search_str = '';
			}
			//$slug = $item_code; //'toys';
			$query->setData('query_text', $search_str);
			
			if ($query->getQueryText() != '') {
				if ($this->_objectManager->get(\Magento\CatalogSearch\Helper\Data::class)->isMinQueryLength()) {
					$query->setId(0)->setIsActive(1)->setIsProcessed(1);
				} else {
					$query->saveIncrementalPopularity();

					$redirect = $query->getRedirect();
					if ($redirect && $this->_url->getCurrentUrl() !== $redirect) {
						$this->getResponse()->setRedirect($redirect);
						return;
					}
				}

				$this->_objectManager->get(\Magento\CatalogSearch\Helper\Data::class)->checkNotes();

				$this->_view->loadLayout();
				$this->_view->renderLayout();
			} else {
				$this->getResponse()->setRedirect($this->_redirect->getRedirectUrl());
			}
		} else {
			$this->_redirect('noRoute');
			return false;
		}*/        
    }
}