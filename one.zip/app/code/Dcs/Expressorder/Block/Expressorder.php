<?php
namespace Dcs\Expressorder\Block;
 
class Expressorder extends \Magento\Framework\View\Element\Template
{    
	protected $_dataHelper;
	
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,        
        \Dcs\Expressorder\Helper\Data $dataHelper,		
        array $data = []
    ) {        
        $this->_dataHelper = $dataHelper;		
        parent::__construct(
            $context,
            $data
        );
    }
	public function isEnabledModule() {
		return $this->_dataHelper->isEnabled();		
	 }
   
}