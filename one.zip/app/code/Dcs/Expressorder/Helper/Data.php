<?php
/**
 * Expressorder data helper
 */
namespace Dcs\Expressorder\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	const XML_PATH_ENABLE 	  = "expressorder/view/enabled";
	
    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->_scopeConfig = $scopeConfig;        
        parent::__construct($context);
    }    
   
	public function isEnabled()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->isSetFlag(self::XML_PATH_ENABLE,$storeScope);
    }	
	
	/*public function isCustomerLoggedIn()
	{
		return $this->_customerSession;
	}*/	

}
