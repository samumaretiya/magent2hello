<?php 
namespace Dcs\ProductAttchments\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{ 
     
    const XML_PATH_FOR_FILE_TYPE = 'productpdf_section/general/file_type';

     
    
    public function getAllowedTypeData()
    {
        $allowedType =  $this->scopeConfig->getValue(
            self::XML_PATH_FOR_FILE_TYPE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
         
        return $allowedType;

    }
    public function getAllowedType(){
        $allowedType = $this->getAllowedTypeData();
        $typeArray = explode(",", $allowedType);
        return $typeArray;
    }

}
