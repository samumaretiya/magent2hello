<?php
namespace Dcs\ProductAttchments\Model\ResourceModel;

class Attchments extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('dcs_product_upload', 'pdf_id');
    }
}
?>