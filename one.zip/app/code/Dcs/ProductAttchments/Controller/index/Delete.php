<?php
namespace Dcs\ProductAttchments\Controller\Index;
  

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page; 

class Delete extends Action
{
     
    protected $resultPageFactory;
    protected $message = array();
    protected $me = array();
   public function __construct(
        Context $context,
        \Dcs\ProductAttchments\Model\Attchments $Attchments,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory 
    ){
        parent::__construct($context); 
        $this->attchModel = $Attchments;
        $this->resultJsonFactory = $resultJsonFactory; 
    }

     
    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create(); 
         
        try{
          
           $id = (int)$this->getRequest()->getParam("id"); 
           if($id){
            $model = $this->attchModel->load($id)->delete();
                 
            return $resultJson->setData(['success' => "file has been deleted successfully.",'id'=>$id]); 
           }
             
            return $resultJson->setData(['error' =>"can not find item to delete."]);
        }  catch (\Exception $e) {                
                 return $resultJson->setData(['error' => $e->getMessage()]);
        }  

    }
}