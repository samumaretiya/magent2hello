<?php
namespace Dcs\ProductAttchments\Controller\Index;
  

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page; 

class Save extends Action
{
    protected $_objectManager;
    protected $resultPageFactory;
    protected $message = array();
    protected $me = array();
   public function __construct(
        Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory 
    ){
        parent::__construct($context);
        $this->_objectManager = $objectManager;
        $this->resultJsonFactory = $resultJsonFactory; 
    }

     
    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();    
        $data = $this->getRequest()->getParams();
        $helperAllowedType = $this->_objectManager->get('Dcs\ProductAttchments\Helper\Data')->getAllowedType(); 
         $numToTxtArr = array(1 => '_1', 2 => '_2', 3 => '_3', 4 => '_4', 5 => '_5', 6 => '_6', 7 => '_7', 8 => '_8', 9 => '_9', 10 => '_10');
        foreach($numToTxtArr as $k => $value){         
           if (isset($_FILES['fileToUpload'.$value]) && isset($_FILES['fileToUpload'.$value]['name']) && strlen($_FILES['fileToUpload'.$value]['name'])) {
                try{
                    $uploader = $this->_objectManager->create(
                        'Magento\MediaStorage\Model\File\Uploader',
                        ['fileId' => 'fileToUpload'.$value]
                    );
                    $uploader->setAllowedExtensions($helperAllowedType);
                    /** @var \Magento\Framework\Image\Adapter\AdapterInterface $imageAdapter */
                    $imageAdapter = $this->_objectManager->get('Magento\Framework\Image\AdapterFactory')->create();
                    $uploader->setAllowRenameFiles(true);
                    $uploader->setFilesDispersion(true);
                    /** @var \Magento\Framework\Filesystem\Directory\Read $mediaDirectory */
                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                        ->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
                    $result = $uploader->save($mediaDirectory->getAbsolutePath('catalog/product/pdf'));
                     
                    if($result['error']==0)
                    {
                        $data['fileToUpload'][$k] = 'catalog/product/pdf' . $result['file'];
                    } else {
                        $data['fileToUpload'][$k]= '';
                    }
                } catch (\Exception $e) { 
                    $message['status'] = "error";
                    $message['message'] = $e->getMessage();
                    // print_r($message);
                    return $resultJson->setData(['error' => $message , 'id'=> $k]);
                }            
            } else {
                if (isset($data['fileToUpload'.$value]) && isset($data['fileToUpload'.$value]['value'])) {
                     $data['fileToUpload'.$value] = ''; 
                     $data['fileToUpload'][$k] = '';
                }
            }
        }
        try{
            $attchModel = $this->_objectManager->get("Dcs\ProductAttchments\Model\Attchments");
            if(isset($data['fileToUpload'])){ 
                $count = 0; $me = '';
                foreach($data['fileToUpload'] as $k => $value){
                    if($value != ''){                
                        $attchModel->setPdfName($data['fileName-'.$k])
                                    ->setPdfUrl($value)
                                    ->setProductId($data['product_id']);
                        $attchModel->save(); 
                        $attchModel->unsetData();
                        $message['id'] = $k;
                        $message['status'] = "success";
                        $message['message'] = "Product file upload successfully.";
                        $me[] = $message; 
                        $count++;
                    }
                    if(empty($me)){
                        return;
                    }
                }
            }
            if(empty($me)){
                return $resultJson->setData('');
            }
            // print_r($message); 
             return $resultJson->setData(['success' => $me , 'count'=> $count]);
        }  catch (\Exception $e) { 
                $message[$k]['status'] = "error";
                $message[$k]['message'] = $e->getMessage();
                // print_r($message); 
                 return $resultJson->setData(['error' => $message]);
            }  

    }
}
