var config = {
	paths: { 
		'dcs/homebanner': 'Dcs_Homebanner/js/owl.carousel.min',			 
	},
	shim: {		 
		'dcs/homebanner': {
			deps: ['jquery']
		},		 	 
	}
};
