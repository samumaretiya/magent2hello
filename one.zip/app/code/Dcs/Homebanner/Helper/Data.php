<?php 
namespace Dcs\Homebanner\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{ 
     
    const XML_PATH_ENABLED = 'homebanner_section/general/enable';

    const MOBILE_VALUE = 0;

    const DESKTOP_VALUE = 1;

    const BOTH_VALUE = 2;

    const MOBILE_LABEL = "Mobile";

    const DESKTOP_LABEL = "Desktop";

    const BOTH_LABEL = "Both";
 
    /**
     * Retrieve option array
     *
     * @return string[]
     */
    public static function getOptionArray()
    {
        return [self::MOBILE_VALUE => self::MOBILE_LABEL, self::DESKTOP_VALUE => self::DESKTOP_LABEL,self::BOTH_VALUE => self::BOTH_LABEL];
    }
    
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    } 
    public function checkDevice()
    {
        $iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
        $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
        $mobile = strpos($_SERVER['HTTP_USER_AGENT'],"Mobile");
        $palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
        $berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
        $ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
        if ($iphone || ($android && $mobile) || $palmpre || $ipod || $berry == true)
        {
            return 1;
        } 
        return 0;
    }   

    public function getMobileArray(){
        return [self::MOBILE_VALUE , self::BOTH_VALUE];
    } 

    public function getDesktopArray(){
        return [self::DESKTOP_VALUE ,self::BOTH_VALUE];
    } 
}