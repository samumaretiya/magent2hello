<?php
/**
 * Adminhtml contactus list block
 *
 */
namespace Dcs\Contactus\Block\Adminhtml;

class Contactus extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_contactus';
        $this->_blockGroup = 'Dcs_Contactus';
        $this->_headerText = __('Contactus');
        $this->_addButtonLabel = __('Add New Contactus');
        parent::_construct();
        if ($this->_isAllowedAction('Dcs_Contactus::save')) {
            $this->buttonList->update('add', 'label', __('Add New Contactus'));
        } else {
            $this->buttonList->remove('add');
        }
		$this->buttonList->remove('add');
    }
    
    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
