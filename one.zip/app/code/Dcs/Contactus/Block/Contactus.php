<?php

namespace Dcs\Contactus\Block;

/**
 * Contactus content block
 */
class Contactus extends \Magento\Framework\View\Element\Template
{
    /**
     * Contactus collection
     *
     * @var Dcs\Contactus\Model\ResourceModel\Contactus\Collection
     */
    protected $_contactusCollection = null;
    
    /**
     * Contactus factory
     *
     * @var \Dcs\Contactus\Model\ContactusFactory
     */
    protected $_contactusCollectionFactory;
    
    /** @var \Dcs\Contactus\Helper\Data */
    protected $_dataHelper;
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Dcs\Contactus\Model\ResourceModel\Contactus\CollectionFactory $contactusCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Dcs\Contactus\Model\ResourceModel\Contactus\CollectionFactory $contactusCollectionFactory,
        \Dcs\Contactus\Helper\Data $dataHelper,
		\Magento\Directory\Model\Region $regiondata,
        array $data = []
    ) {
        $this->_contactusCollectionFactory = $contactusCollectionFactory;
        $this->_dataHelper = $dataHelper;
		$this->regiondata = $regiondata;
        parent::__construct(
            $context,
            $data
        );
    }
	 public function isEnabledModule()
    {
		 return $this->_dataHelper->isEnabled();
    }
    
	public function regionList()
    {
		$region_list = $this->regiondata->getCollection()->addFieldToFilter('country_id','AU');
		return $region_list;		
    }
	
    
    /**
     * Retrieve contactus collection
     *
     * @return Dcs\Contactus\Model\ResourceModel\Contactus\Collection
     */
    protected function _getCollection()
    {
        $collection = $this->_contactusCollectionFactory->create();
        return $collection;
    }
    
    /**
     * Retrieve prepared contactus collection
     *
     * @return Dcs\Contactus\Model\ResourceModel\Contactus\Collection
     */
    public function getCollection()
    {
        if (is_null($this->_contactusCollection)) {
            $this->_contactusCollection = $this->_getCollection();
            $this->_contactusCollection->setCurPage($this->getCurrentPage());
            $this->_contactusCollection->setPageSize($this->_dataHelper->getContactusPerPage());
            $this->_contactusCollection->setOrder('published_at','asc');
        }

        return $this->_contactusCollection;
    }
    
    /**
     * Fetch the current page for the contactus list
     *
     * @return int
     */
    public function getCurrentPage()
    {
        return $this->getData('current_page') ? $this->getData('current_page') : 1;
    }
    
    /**
     * Return URL to item's view page
     *
     * @param Dcs\Contactus\Model\Contactus $contactusItem
     * @return string
     */
    public function getItemUrl($contactusItem)
    {
        return $this->getUrl('*/*/view', array('id' => $contactusItem->getId()));
    }
    
    /**
     * Return URL for resized Contactus Item image
     *
     * @param Dcs\Contactus\Model\Contactus $item
     * @param integer $width
     * @return string|false
     */
    public function getImageUrl($item, $width)
    {
        return $this->_dataHelper->resize($item, $width);
    }
    
    /**
     * Get a pager
     *
     * @return string|null
     */
    public function getPager()
    {
        $pager = $this->getChildBlock('contactus_list_pager');
        if ($pager instanceof \Magento\Framework\Object) {
            $contactusPerPage = $this->_dataHelper->getContactusPerPage();

            $pager->setAvailableLimit([$contactusPerPage => $contactusPerPage]);
            $pager->setTotalNum($this->getCollection()->getSize());
            $pager->setCollection($this->getCollection());
            $pager->setShowPerPage(TRUE);
            $pager->setFrameLength(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            )->setJump(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame_skip',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            );

            return $pager->toHtml();
        }

        return NULL;
    }
}
