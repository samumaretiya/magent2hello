<?php

namespace Dcs\Contactus\Model;

/**
 * Contactus Model
 *
 * @method \Dcs\Contactus\Model\Resource\Page _getResource()
 * @method \Dcs\Contactus\Model\Resource\Page getResource()
 */
class Contactus extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Dcs\Contactus\Model\ResourceModel\Contactus');
    }

}
