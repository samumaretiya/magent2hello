<?php

namespace Dcs\Contactus\Controller;

use Magento\Framework\App\ActionInterface;

interface ContactusInterface extends ActionInterface
{
}
