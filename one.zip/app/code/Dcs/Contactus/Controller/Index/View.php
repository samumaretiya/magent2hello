<?php

namespace Dcs\Contactus\Controller\Index;

use Dcs\Contactus\Controller\ContactusInterface;

class View extends \Dcs\Contactus\Controller\AbstractController\View implements ContactusInterface
{

}
