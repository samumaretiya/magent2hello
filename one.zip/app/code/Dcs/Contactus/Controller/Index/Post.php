<?php
namespace Dcs\Contactus\Controller\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
//use Dcs\Contactus\Controller\AbstractAction;

class Post extends \Magento\Framework\App\Action\Action	
{
	 const XML_PATH_CUSTOMER_EMAIL  = 'contactus/view/email_template';
	 const XML_PATH_ADMIN_EMAIL  = 'contactus/view/admin_email'; 
	 const XML_PATH_EMAIL_SENDER = 'contact/email/sender_email_identity';
	
	public function __construct(
        Context $context,
		\Magento\Framework\Controller\ResultFactory $resultFactory,
		\Magento\Framework\Translate\Inline\StateInterface $StateInterface,
		\Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
		\Dcs\Contactus\Helper\Data $helperContactus,
		\Dcs\Contactus\Model\Contactus $_contactusModel,
		\Dcs\Contactus\Helper\Email $emailHelper
		
    ){
        parent::__construct($context);		
		$this->resultFactory = $resultFactory;
		$this->StateInterface = $StateInterface;
		$this->StoreManagerInterface = $StoreManagerInterface;
		$this->_contactusModel = $_contactusModel;  
		$this->helperContactus = $helperContactus;
		$this->EmailHelper = $emailHelper;
    }
	public function execute()
	{
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$post 			= $this->getRequest()->getPostValue();
		/*echo '<pre>';
			print_r($post);
		echo '</pre>';
		exit;*/
		
		$name 		= $this->getRequest()->getPost('name');
		$last_name 	= $this->getRequest()->getPost('last_name');		
		$company	= $this->getRequest()->getPost('company');
		$phone 		= $this->getRequest()->getPost('phone');
		$email 		= $this->getRequest()->getPost('email'); 
		$catalogue	= $this->getRequest()->getPost('catalogue');
		$address 	= $this->getRequest()->getPost('address');
		$suburb 	= $this->getRequest()->getPost('suburb');		
		$state 		= $this->getRequest()->getPost('state');
		$specials 	= $this->getRequest()->getPost('specials');				
		$comment 	= $this->getRequest()->getPost('comment');	 
		//$postcode 		= $this->getRequest()->getPost('postcode');
		if (!$post) {
			$this->_redirect('*/*/');
			return;
		}		 
		try {
			
			//$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE; 
			$error = false;
			
			$this->_contactusModel->setData('name',$name);
			$this->_contactusModel->setData('last_name',$last_name);
			$this->_contactusModel->setData('company',$company);
			$this->_contactusModel->setData('phone',$phone);
			$this->_contactusModel->setData('email',$email);
			$this->_contactusModel->setData('catalogue',$catalogue);
			$this->_contactusModel->setData('address',$address);
			$this->_contactusModel->setData('suburb',$suburb);
			$this->_contactusModel->setData('state',$state);
			$this->_contactusModel->setData('specials',$specials);
			$this->_contactusModel->setData('comment',$comment);		
			//$this->_contactusModel->setData('postcode',$postcode);
			
			if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
				$error = true;
			}			
			if (!\Zend_Validate::is(trim($post['email']), 'EmailAddress')) {
				$error = true;
			}
			if($post['g-recaptcha-response'] == ''){
				$error = true;
			} 
			if ($error) {
				throw new \Exception();
			}

			try { 
				$postObject = new \Magento\Framework\DataObject();
				$postObject->setData($post);
				/****************************************************************/
				//$helper = $this->_objectManager->get('Dcs\Contactus\Helper\Data');
				
				/* Receiver Detail  */
				$receiveremail = $this->helperContactus->Recipientemail();
				
				$receiverInfo = [
					'name' => 'Contact Us',
					'email' => $receiveremail,
				];

				$sendername = $this->helperContactus->GeneralName();
				$senderemail = $this->helperContactus->GeneralEmail();
				
				$senderInfo = [
					'name' => $sendername,
					'email' => $senderemail,
				];				 
				
				/****************** Email Send Code start *****************************************************/			
				$customerInfo = [
					'name' =>   $name,
					'email' => $email,
				];
				
				/*Email to admin start*/
					$this->EmailHelper->contactEnquiryMailSendMethod($postObject,$senderInfo,$receiverInfo); 	
				/*Email to admin end*/
				
				/*Email to customer start*/
					$this->EmailHelper->contactMailSendMethodToCustomer($postObject,$senderInfo,$customerInfo);	
				/*Email to customer end*/				
				/****************** End Send Code start *****************************************************/
				
				// Data base store data
				$this->_contactusModel->save();
				$this->helperContactus->setMessage(true,__('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.'));
				//$this->messageManager->addSuccess(__('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.'));
			} catch (\Exception $e) {
				$this->helperContactus->setMessage(false,__('We can\'t process your request right now. Sorry, that\'s all we know.'));
				//$this->messageManager->addError(__('We can\'t process your request right now. Sorry, that\'s all we know.'));
			}

		} catch (\Exception $e) {
			$this->helperContactus->setMessage(false,__('We can\'t process your request right now. Sorry, that\'s all we know.'));
			//$this->messageManager->addError(__('We can\'t process your request right now. Sorry, that\'s all we know.'));
		} 		
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
