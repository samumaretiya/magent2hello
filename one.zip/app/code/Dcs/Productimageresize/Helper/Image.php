<?php
namespace Dcs\Productimageresize\Helper;  

class Image extends \Magento\Catalog\Helper\Image
{
	public function getWidth()
    {
        return 283;
    }
}
 ?>       
