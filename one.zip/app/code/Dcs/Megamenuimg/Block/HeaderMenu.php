<?php 
namespace Dcs\Megamenuimg\Block; 

class HeaderMenu extends \Magento\Framework\View\Element\Template 
{
	 
	protected $objectManager;

	protected $_catalogHelper;

	protected$_catagoryFactory;

	protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
	 
    public function __construct(
    	\Magento\Catalog\Block\Product\Context $context, 
    	\Magento\Catalog\Helper\Category $catalogHelper,
    	\Magento\Catalog\Model\Category $catagoryFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager,   
    	array $data = []) 
    {
        parent::__construct($context, $data); 
         $this->objectManager = $objectManager;
         $this->_catagoryFactory = $catagoryFactory;
         $this->_catalogHelper = $catalogHelper; 
    }  
     
    public function getImageUrl($image = ''){
        $media_dir = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if($image){
        	return $media_dir."catalog/category/".$image;
        }
    }

    public function getAllCategory()
    {
    	return $this->_catalogHelper->getStoreCategories();
    }

    public function getCategoryData($category_id = 0)
    {
    	return $this->_catagoryFactory->load($category_id);
    }

    public function getCategoryUrl($category = array())
    {
    	return $this->_catalogHelper->getCategoryUrl($category);
    }
}
