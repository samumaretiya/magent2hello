<?php

namespace Dcs\Megamenuimg\Setup;

use Magento\Eav\Model\Entity\Setup\Context;
use Magento\Eav\Setup\EavSetup;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Group\CollectionFactory;
use Magento\Eav\Setup\EavSetupFactory;

class AttributeSetup extends EavSetup {
	
	private $eavSetupFactory;

	public function __construct(
		ModuleDataSetupInterface $setup,
		Context $context,
		CacheInterface $cache,
		CollectionFactory $attrGroupCollectionFactory,		
		EavSetupFactory $eavSetupFactory
	) {		
		parent :: __construct($setup, $context, $cache, $attrGroupCollectionFactory, $eavSetupFactory);		
	} 

	public function installAttributes($customerSetup) {		
		//$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);		
        $entityTypeId = $customerSetup->getEntityTypeId(\Magento\Catalog\Model\Category::ENTITY);
        $attributeSetId = $customerSetup->getDefaultAttributeSetId($entityTypeId);
		
		 // Menu First Image url		
		 $customerSetup->addAttribute(
			\Magento\Catalog\Model\Category::ENTITY, 'menu_first_img_link', [
			 	'type' => 'varchar',
				'label' => 'Menu First Image Link',
				'input' => 'text',				
				'sort_order' => 8,
				'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
				'wysiwyg_enabled' => false,
				'is_html_allowed_on_front' => false,
			 	'source' => '',
			 	'default' => null,
			 	'visible' => true,
			 	'required' => false,
				'is_user_defined' => true,
			 	'note' => '',
				'group' => 'General Information',
			]
		);
		
		// Menu Second Image url		
		 $customerSetup->addAttribute(
			\Magento\Catalog\Model\Category::ENTITY, 'menu_second_img_link', [
			 	'type' => 'varchar',
				'label' => 'Menu Second Image Link',
				'input' => 'text',				
				'sort_order' => 9,
				'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
				'wysiwyg_enabled' => false,
				'is_html_allowed_on_front' => false,
			 	'source' => '',
			 	'default' => null,
			 	'visible' => true,
			 	'required' => false,
				'is_user_defined' => true,
			 	'note' => '',
				'group' => 'General Information',
			]
		);		
        $idg =  $customerSetup->getAttributeGroupId($entityTypeId, $attributeSetId, 'General Information');
		
		// Menu First Image URL
		$customerSetup->addAttributeToGroup(
            $entityTypeId,
            $attributeSetId,
            $idg,
            'menu_first_img_link',
            50
        );
		
		// Menu Second Image URL
		$customerSetup->addAttributeToGroup(
            $entityTypeId,
            $attributeSetId,
            $idg,
            'menu_second_img_link',
            51
        );		
	}
} 
