<?php
namespace Dcs\Megamenuimg\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Catalog\Setup\CategorySetupFactory;

class InstallData implements InstallDataInterface
{
    /**
     * Category setup factory
     *
     * @var CategorySetupFactory
     */
    private $categorySetupFactory;
    
    /**
     * EAV setup factory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * Init
     *
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        
        //$categorySetup = $this->categorySetupFactory->create(['setup' => $setup]);
        $entityTypeId = $eavSetup->getEntityTypeId(\Magento\Catalog\Model\Category::ENTITY);
        $attributeSetId = $eavSetup->getDefaultAttributeSetId($entityTypeId);
		
		// Menu Thumbnail
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'menu_thumbnail', [
                'type' => 'varchar',
                'label' => 'Menu Thumbnail',
                'input' => 'image',
                'backend' => 'Magento\Catalog\Model\Category\Attribute\Backend\Image',
                'required' => false,
                'sort_order' => 5,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
				'note' => 'Menu Thumbnail',
                'group' => 'General Information',
            ]
        );
		
		// Menu First Image
		$eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'menu_first_img', [
                'type' => 'varchar',
                'label' => 'Menu First Image',
                'input' => 'image',
                'backend' => 'Magento\Catalog\Model\Category\Attribute\Backend\Image',
                'required' => false,
                'sort_order' => 6,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
				'note' => 'Menu First Image',
                'group' => 'General Information',
            ]
        );
		
		// Menu Second Image
		$eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'menu_second_img', [
                'type' => 'varchar',
                'label' => 'Menu Second Image',
                'input' => 'image',
                'backend' => 'Magento\Catalog\Model\Category\Attribute\Backend\Image',
                'required' => false,
                'sort_order' => 7,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
				'note' => 'Menu Second Image',
                'group' => 'General Information',
            ]
        );        
		
        $idg =  $eavSetup->getAttributeGroupId($entityTypeId, $attributeSetId, 'General Information');
		
		// Menu Thumbnail
		 $eavSetup->addAttributeToGroup(
            $entityTypeId,
            $attributeSetId,
            $idg,
            'menu_thumbnail',
            47
        );
		
		// Menu First Image
		$eavSetup->addAttributeToGroup(
            $entityTypeId,
            $attributeSetId,
            $idg,
            'menu_first_img',
            48
        );
		
		// Menu Second Image
		$eavSetup->addAttributeToGroup(
            $entityTypeId,
            $attributeSetId,
            $idg,
            'menu_second_img',
            49
        );
        //$installer->endSetup();
    }
}