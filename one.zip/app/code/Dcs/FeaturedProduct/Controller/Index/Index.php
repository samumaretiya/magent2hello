<?php

namespace Dcs\FeaturedProduct\Controller\Index;


use Dcs\FeaturedProduct\Block\Featured;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    /** @var PageFactory */
    protected $pageFactory;
 
    protected $helper;

    public function __construct(
        Context $context,
        PageFactory $pageFactory,
        \Dcs\FeaturedProduct\Helper\Data $helper
        //array $data = []
    )
    {
        $this->pageFactory = $pageFactory;
        $this->helper = $helper; 
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->pageFactory->create();
        if($this->helper->isEnabledForCustomList()){
           
            return $result; 
        }  
        $this->_redirect('noRoute');
                return false;
        
    }
}