<?php

namespace Dcs\FeaturedProduct\Model;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;
class Options extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**#@+
     * Status values
     */
    const STATUS_YES = 1;

    const STATUS_NO = 0; 


    public function getAllOptions()
    {
        /* your Attribute options list*/
        $this->_options=[  ['label'=>  __('-- Please Select --'), 'value'=>''],
                          ['label'=>  __('Yes'), 'value'=>self::STATUS_YES],
                          ['label'=>  __('No'), 'value'=>self::STATUS_NO]
                         ];
        return $this->_options;
    }
 
    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }

    public function getFlatColumns()
    {
        $attributeCode = $this->getAttribute()->getAttributeCode();
        return [
            $attributeCode => [
                'unsigned' => false,
                'default' => null,
                'extra' => null,
                'type' => Table::TYPE_INTEGER,
                'nullable' => true,
                'comment' => 'Featured Options  ' . $attributeCode . ' column',
            ],
        ];
    }
}