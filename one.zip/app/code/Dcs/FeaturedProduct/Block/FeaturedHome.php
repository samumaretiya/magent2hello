<?php

namespace Dcs\FeaturedProduct\Block;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\View\Element\Template\Context;
use Dcs\FeaturedProduct\Helper\Data;
use Magento\Catalog\Block\Product\ListProduct;

class FeaturedHome extends \Magento\Framework\View\Element\Template 
{
	protected $helper;

	protected $listProduct;

	public function __construct(
	   Context $context, 
	   CollectionFactory $productFactory,
	   Data $helper,
	   ListProduct $listProduct,
	   array $data = array()       
	) {
	   $this->_productFactory   = $productFactory;
	   $this->helper = $helper;
	   $this->listProduct = $listProduct;
	   parent::__construct($context, $data);
	}


    public function getProductCollection() {
	   $productCollection = $this->_productFactory->create();
	   $productCollection->addAttributeToSelect(array('id','url_key','image','name','price','status','featured_list','small_image','thumbnail','visibility')) 
	   					 ->addAttributeToFilter('featured_list',\Dcs\FeaturedProduct\Model\Options::STATUS_YES) 
	   					 ->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH)
    					 ->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)
    	 				 ->setPageSize(10)
    	 				 ->setOrder('id','DESC');
	   return $productCollection;
	}

	public function isEnabled(){
		return $this->helper->isEnabledForHome();
	}

	public function isCustomPageEnabled(){
		return $this->helper->isEnabledForCustomList();
	}
	
	public function getProductPrice($product){
		return $this->listProduct->getProductPrice($product);
	}

	public function getImage($product ,$image = ''){
		return $this->listProduct->getImage($product,$image);
	}
}