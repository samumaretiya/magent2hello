<?php 
namespace Dcs\FeaturedProduct\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{ 
     
    const XML_PATH_ENABLED_HOME = 'featured_section/general/enable';

    const XML_PATH_ENABLED_PAGE = 'featured_section/general/enable_page';
 
    /**
     * Retrieve option array
     *
     * @return string[]
     */     
    public function __construct(
    \Magento\Framework\App\Helper\Context $context,  
    \Magento\Eav\Model\Entity\Attribute $eavAttr
    ) { 
        $this->eavAttr = $eavAttr;
        parent::__construct($context);
    }   

    public function isEnabledForHome()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED_HOME,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    } 

    public function isEnabledForCustomList()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED_PAGE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    } 
    public function getProductAttrLabel($attrCode){
        return $this->eavAttr->loadByCode("catalog_product", $attrCode)->getStoreLabel();
    }
     
}