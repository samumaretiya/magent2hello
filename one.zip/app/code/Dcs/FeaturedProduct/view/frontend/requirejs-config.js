var config = {
	paths: { 
		'dcs/featured': 'Dcs_FeaturedProduct/js/owl.carousel.min',			 
	},
	shim: {		 
		'dcs/featured': {
			deps: ['jquery']
		},		 	 
	}
};
