<?php
namespace Dcs\Faqs\Model;

class Faqs extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Dcs\Faqs\Model\ResourceModel\Faqs');
    }
}
?>
