var config = {
    map: {
        '*': {
            amasty_js_color: 'Amasty_Xsearch/jscolor/jscolor'
        }
    }
};
