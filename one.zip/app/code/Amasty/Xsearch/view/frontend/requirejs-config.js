var config = {
    map: {
        '*': {
            amasty_xsearch_autocomplete: 'Amasty_Xsearch/autocomplete'
        }
    }
};
