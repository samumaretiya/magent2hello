<?php
/**
 * PL Development.
 *
 * @category    PL
 * @author      Linh Pham <plinh5@gmail.com>
 * @copyright   Copyright (c) 2016 PL Development. (http://www.polacin.com)
 */
namespace PL\Westpac\Model;

class Payway extends \Magento\Payment\Model\Method\Cc
{
    const METHOD_CODE = 'payway';

    const STATUS_APPROVED = 'Approved';

    const PAYMENT_ACTION_AUTH_CAPTURE = 'authorize_capture';

    const PAYMENT_ACTION_AUTH = 'authorize';

    protected $_code = self::METHOD_CODE;

    protected $_canAuthorize = true;

    /**
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * @var bool
     */
    protected $_canCapturePartial = true;

    /**
     * @var bool
     */
    protected $_canCaptureOnce = true;

    /**
     * @var bool
     */
    protected $_canRefund = true;

    /**
     * @var bool
     */
    protected $_canRefundInvoicePartial = true;

    /**
     * @var bool
     */
    protected $_isGateway = true;

    /**
     * @var array
     */
    protected $_supportedCurrencyCodes = array('AUD','NZD');

    /**
     * @var \PL\Westpac\Helper\Data
     */
    protected $paywayHelper;

    /**
     * @var \PL\Westpac\Logger\Logger
     */
    protected $plLogger;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $filesystem;

    public function __construct(
        \PL\Westpac\Helper\Data $paywayHelper,
        \PL\Westpac\Logger\Logger $plLogger,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $moduleList,
            $localeDate,
            $resource,
            $resourceCollection,
            $data
        );
        $this->paywayHelper = $paywayHelper;
        $this->plLogger = $plLogger;
        $this->filesystem = $filesystem;
    }

    /**
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validate()
    {
        parent::validate();
        $paymentInfo = $this->getInfoInstance();
        if ($paymentInfo instanceof \Magento\Sales\Model\Order\Payment) {
            $paymentInfo->getOrder()->getBaseCurrencyCode();
        } else {
            $paymentInfo->getQuote()->getBaseCurrencyCode();
        }
        return $this;
    }

    public function canUseForCurrency($currencyCode)
    {
        if (!in_array($currencyCode, $this->_supportedCurrencyCodes)) {
            return false;
        }
        return true;
    }

    /**
     * @return string
     */
    public function getCaFile()
    {
        return dirname(__FILE__) . '/Api/cacerts.crt';
    }

    /**
     * @return string
     */
    public function getCertificate()
    {
        return dirname(__FILE__) . '/Api/ccapi.pem';
    }

    /**
     * @return string
     */
    public function getLogDir()
    {
        return  $this->filesystem
            ->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR)
            ->getAbsolutePath().'log/westpac/';
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getOrderPrefix()
    {
        $prefix='';
        if ($this->getConfigData('order_prefix') !="") {
            $prefix = substr($this->getConfigData('order_prefix'), 0, 8);
        }
        return $prefix;
    }

    public function getOrderType()
    {
        if ($this->getConfigData('payment_action') == 'authorize') {
            return 'preauth';
        }
        return 'capture';
    }


    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $payment->setCcTransId($this->getOrderPrefix().$payment->getOrder()->getIncrementId());
        $this->setAmount($amount)->setPayment($payment);
        $result = $this->processRequest($payment);
        $errorMessage = false;
        if (isset($result['response.summaryCode'])) {
            if ($result['response.summaryCode'] == '0') {
                $payment
                    ->setStatus(self::STATUS_APPROVED)
                    ->setTransactionId($result['response.receiptNo'])
                    ->setLastTransId($result['response.receiptNo'])
                    ->setIsTransactionClosed(0);
            } else {
                $errorMessage = __("Gateway error: %1", $result["response.text"]);
            }
        } else {
            $errorMessage = __('There has been an error processing your payment.');
        }

        if ($errorMessage) {
            throw new \Magento\Framework\Exception\LocalizedException($errorMessage);
        }

        return $this;
    }


    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $payment->setCcTransId($this->getOrderPrefix().$payment->getOrder()->getIncrementId());
        $this->setAmount($amount)->setPayment($payment);
        $result = $this->processRequest($payment);
        $errorMessage = false;
        if (isset($result['response.summaryCode'])) {
            if ($result['response.summaryCode'] == '0') {
                $payment
                    ->setStatus(self::STATUS_APPROVED)
                    ->setTransactionId($result['response.receiptNo'])
                    ->setLastTransId($result['response.receiptNo'])
                    ->setIsTransactionClosed(0);
            } else {
                $errorMessage = __("Gateway error: %1", $result["response.text"]);
            }
        } else {
            $errorMessage = __('There has been an error processing your payment.');
        }

        if ($errorMessage) {
            throw new \Magento\Framework\Exception\LocalizedException($errorMessage);
        }

        return $this;
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $this->setAmount($amount)->setPayment($payment);
        $result = $this->processRefund($payment);
        $errorMessage = false;
        if (isset($result['response.summaryCode'])) {
            if ($result['response.summaryCode'] == '0') {
                $payment
                    ->setStatus(self::STATUS_APPROVED)
                    ->setTransactionId($result['response.receiptNo'])
                    ->setLastTransId($result['response.receiptNo'])
                    ->setIsTransactionClosed(1);

            } else {
                $errorMessage = __('Gateway error: %1', $result["response.text"]);
            }
        } else {
            $errorMessage = __('There has been an error processing your payment.');
        }

        if ($errorMessage) {
            throw new \Magento\Framework\Exception\LocalizedException($errorMessage);
        }

        return $this;
    }


    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @return array
     */
    protected function processRequest(\Magento\Payment\Model\InfoInterface $payment)
    {
        $init = "certificateFile=" . $this->getCertificate() . "&" .
            "caFile=" . $this->getCaFile() . "&" .
            "logDirectory=" . $this->getLogDir();
        $payWayApi = new \PL\Westpac\Model\Api\PayWayAPI;
        $payWayApi->initialise($init);
        $params = [];
        $params["order.type"] = $this->getOrderType();
        $params["customer.username"] = $this->getConfigData('username');
        $params["customer.password"] = $this->getConfigData('password');
        $params["customer.merchant"] = $this->getConfigData('merchant_id');
        $params["card.PAN"] = $payment->getCcNumber();
        $params["card.CVN"] = $payment->getCcCid();
        $params["card.expiryYear"] = substr($payment->getCcExpYear(), 2, 2);
        $params["card.expiryMonth"] = str_pad($payment->getCcExpMonth(), 2, '0', STR_PAD_LEFT);
        $params["customer.orderNumber"] = $payment->getCcTransId();
        $params["card.currency"] = $payment->getOrder()->getBaseCurrencyCode();
        $params["order.amount"] = $this->getAmount() * 100;
        $params["order.ECI"] = "SSL";
        $requestText = $payWayApi->formatRequestParameters($params);
        $responseText = $payWayApi->processCreditCard($requestText);
        $result = $payWayApi->parseResponseParameters($responseText);
        return $result;
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @return array
     */
    protected function processRefund(\Magento\Payment\Model\InfoInterface $payment)
    {
        $init = "certificateFile=" . $this->getCertificate() . "&" .
            "caFile=" . $this->getCaFile() . "&" .
            "logDirectory=" . $this->getLogDir();
        $payWayApi = new \PL\Westpac\Model\Api\PayWayAPI;
        $payWayApi->initialise($init);
        $params = [];
        $params["order.type"] = "refund";
        $params["customer.username"] = $this->getConfigData('username');
        $params["customer.password"] = $this->getConfigData('password');
        $params["customer.merchant"] = $this->getConfigData('merchant_id');
        $params["card.expiryYear"] = substr($payment->getCcExpYear(), 2, 2);
        $params["card.expiryMonth"] = str_pad($payment->getCcExpMonth(), 2, '0', STR_PAD_LEFT);
        $params["customer.orderNumber"] = $payment->getCcTransId()."R";
        $params["customer.originalOrderNumber"] = $payment->getCcTransId();
        $params["card.currency"] = $payment->getOrder()->getBaseCurrencyCode();
        $params["order.amount"] = $this->getAmount() * 100;
        $params["order.ECI"] = "SSL";
        $requestText = $payWayApi->formatRequestParameters($params);
        $responseText = $payWayApi->processCreditCard($requestText);
        $result = $payWayApi->parseResponseParameters($responseText);
        return $result;
    }
}
