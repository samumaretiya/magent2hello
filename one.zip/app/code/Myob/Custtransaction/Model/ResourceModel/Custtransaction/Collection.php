<?php

/**
 * Custtransaction Resource Collection
 */
namespace Myob\Custtransaction\Model\ResourceModel\Custtransaction;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Myob\Custtransaction\Model\Custtransaction', 'Myob\Custtransaction\Model\ResourceModel\Custtransaction');
    }
}
