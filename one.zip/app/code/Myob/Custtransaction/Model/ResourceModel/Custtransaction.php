<?php

namespace Myob\Custtransaction\Model\ResourceModel;

/**
 * Custtransaction Resource Model
 */
class Custtransaction extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('exocusttransaction', 'custtransaction_id');
    }
}
