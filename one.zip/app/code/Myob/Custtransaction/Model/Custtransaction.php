<?php

namespace Myob\Custtransaction\Model;

class Custtransaction extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Myob\Custtransaction\Model\ResourceModel\Custtransaction');
    }

}
