<?php

/**
 * Custtransaction data helper
 */
namespace Myob\Custtransaction\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	
	const XML_PATH_MERCHANT_ID  = 'custtransaction/accountpayment/merchant_id';
	const XML_PATH_SECURITY_USERNAME  = 'custtransaction/accountpayment/security_username';
	const XML_PATH_SECURITY_PASSWORD  = 'custtransaction/accountpayment/security_password';
	const XML_PATH_RECIPIENT_EMAIL = 'custtransaction/accountpayment/recipient_email';
    const XML_PATH_RECIPIENT_NAME = 'custtransaction/accountpayment/recipient_name';
    const XML_PATH_GENERAL_NAME = 'trans_email/ident_general/name';
    const XML_PATH_GENERAL_EMAIL = 'trans_email/ident_general/email';
	
	
	public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager
        
    ) {
        $this->_scopeConfig = $scopeConfig;        
        $this->_storeManager = $storeManager;        
        parent::__construct($context);
    }
	
	
	
	public function AccountMerchantID()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_MERCHANT_ID,$storeScope);
    }
	
	public function SecurityUsername()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_SECURITY_USERNAME,$storeScope);
    }
	
	public function SecurityPassword()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_SECURITY_PASSWORD,$storeScope);
    }
    public function Recipientemail()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_RECIPIENT_EMAIL,$storeScope);
    }
    public function Recipientname()
    {		
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		return $this->scopeConfig->getValue(self::XML_PATH_RECIPIENT_NAME,$storeScope);
    }
	public function GeneralName()
	{
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
 		return $this->scopeConfig->getValue(self::XML_PATH_GENERAL_NAME, $storeScope);
    }
	
	public function GeneralEmail()
	{
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
 		return $this->scopeConfig->getValue(self::XML_PATH_GENERAL_EMAIL, $storeScope);
    }
   	
}
