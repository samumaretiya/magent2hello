<?php

namespace Myob\Custtransaction\Controller\Index;

include $_SERVER['DOCUMENT_ROOT'].'/Qvalent_PayWayAPI.php';

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page; 


class Paymentsave extends Action
{
	
    protected $resultPageFactory; 

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,		
        \Magento\Customer\Model\Session $customerSession 
    ){
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;		
        $this->_customerSession = $customerSession; 
    }

    public function execute()
    {
		$post = $this->getRequest()->getPostValue();
		
		if (!$post) {
			$this->_redirect('*/*/');
			return;
		}		 
		try {			
							$initParams =
						"certificateFile=ccapi.pem" . "&" .
						"caFile=ccapi.pem" . "&" .
						"logDirectory=LOG_DIR";
					$paywayAPI = new Qvalent_PayWayAPI();
					$paywayAPI->initialise( $initParams );
			
					//----------------------------------------------------------------------------
					// Get request information
					//----------------------------------------------------------------------------
					$orderECI               = "SSL";
					$orderType              = "capture";

					$invoice_id        =  $this->getRequest()->getPost('invoice_id');
					$orderAmount        =  $this->getRequest()->getPost('orderAmount');
					$cardNumber             = $this->getRequest()->getPost('cardNumber');
					$cardVerificationNumber = $this->getRequest()->getPost('cardVerificationNumber');
					$cardExpiryYear         = $this->getRequest()->getPost('cardExpiryYear');
					$cardExpiryMonth        = $this->getRequest()->getPost('cardExpiryMonth');	
			
					
			
					
					if($invoice_id!='' && $orderAmount!='' && $cardNumber!='' && $cardVerificationNumber!='' && $cardExpiryYear!='' && $cardExpiryMonth!='')
					{
						$cardCurrency           = "AUD";
						$orderAmountCents       = number_format( (float)$orderAmount * 100, 0, '.', '' );
						
						$helper = $this->_objectManager->get('Myob\Custtransaction\Helper\Data');
						
						$customerMerchant = $helper->AccountMerchantID();
						$customerUsername = $helper->SecurityUsername();
						$customerPassword = $helper->SecurityPassword();
						
						

						/*$customerUsername       = "T10945";
						$customerPassword       = "Augn3xzf7";
						$customerMerchant       = "TEST";*/


						$time=time();	
						$prefix = "TP_";
						$orderNumber            = $prefix.$time;

						$customer_ip = $_SERVER['REMOTE_ADDR']; ///'202.131.115.228';

						//----------------------------------------------------------------------------
						// Process credit card request
						//----------------------------------------------------------------------------
						$requestParameters = array();
						$requestParameters[ "order.type" ] = $orderType;
						$requestParameters[ "customer.username" ] = $customerUsername;
						$requestParameters[ "customer.password" ] = $customerPassword;
						$requestParameters[ "customer.merchant" ] = $customerMerchant;
						$requestParameters[ "customer.orderNumber" ] = $orderNumber;
						$requestParameters[ "customer.originalOrderNumber" ] = $orderNumber;
						$requestParameters[ "card.PAN" ] = $cardNumber;
						$requestParameters[ "card.CVN" ] = $cardVerificationNumber;
						$requestParameters[ "card.expiryYear" ] = $cardExpiryYear;
						$requestParameters[ "card.expiryMonth" ] = $cardExpiryMonth;
						$requestParameters[ "card.currency" ] = $cardCurrency;
						$requestParameters[ "order.amount" ] = $orderAmountCents;
						$requestParameters[ "order.ECI" ] = $orderECI;
						$requestParameters[ "order.ipAddress" ] = $customer_ip;

						$requestText = $paywayAPI->formatRequestParameters( $requestParameters );

						$responseText = $paywayAPI->processCreditCard( $requestText );

						// Parse the response string into an array
						$responseParameters = $paywayAPI->parseResponseParameters( $responseText );

						// Get the required parameters from the response
						$summaryCode = $responseParameters[ "response.summaryCode" ];
						$responseCode = $responseParameters[ "response.responseCode" ];					
						$description = $responseParameters[ "response.text" ];
						$receiptNo = $responseParameters[ "response.receiptNo" ];
						$settlementDate = $responseParameters[ "response.settlementDate" ];
						$creditGroup = $responseParameters[ "response.creditGroup" ];
						$cardSchemeName = $responseParameters[ "response.cardSchemeName" ];	

						if(isset($summaryCode))
						{
							if ($summaryCode == '0')
							{
								$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
								$customerSession = $objectManager->get('Magento\Customer\Model\Session');
								
								$customer_email = $customerSession->getCustomer()->getEmail();
								$customer_name = $customerSession->getCustomer()->getName();
								$customer_account_number = $customerSession->getCustomer()->getAccountNumber();
								
								$model = $this->_objectManager->create('Myob\Custtransaction\Model\Custtransaction');
								$model->setData('cust_account_number',$customer_account_number);
								$model->setData('cust_email',$customer_email);
								$model->setData('invoice_id',$invoice_id);
								$model->setData('amount',$orderAmount);
								$model->setData('order_number',$orderNumber);
								$model->setData('receipt_number',$receiptNo);
								$model->setData('summary_code',$summaryCode);
								$model->setData('summary_description',$description);
								$model->setData('created_time',date('Y-m-d H:i:s'));
								$model->setData('update_time',date('Y-m-d H:i:s'));
								$model->setData('status','0');
								$model->save(); 
								
								try {
										// Receiver Detail
										$receiveremail = $helper->Recipientemail();
										$receivername = $helper->Recipientname();
										
											$receiverInfo = [
												'name' => $receivername,
												'email' => $receiveremail,
											];
											$sendername = $helper->GeneralName();
											$senderemail = $helper->GeneralEmail();
											
											$senderInfo = [
												'name' => $sendername,
												'email' => $senderemail,
											];
											// Assign values for your template variables 
											$emailTemplateVariables = array();
											$emailTemplateVariables = array(
												'customer_name'			=> $customer_name,
												'cust_account_number'	=> $customer_account_number,
												'customer_email' 		=> $customer_email,
												'invoice_id'   			=> $invoice_id,
												'amount'				=> $orderAmount,
												'receipt_number'		=> $receiptNo,
											);			
											//print_r($emailTemplateVariables); exit;
											/* call send mail method from helper or where you define it [ Admin Mail Send ]*/
											$this->_objectManager->get('Myob\Custtransaction\Helper\Email')->accountPaymentMailSendMethod($emailTemplateVariables,$senderInfo,$receiverInfo);
											
											// Customer Mail Send 
											 $customerInfo = [
												'name' =>  $customer_name,
												'email' => $customer_email,
											];
											
											$this->_objectManager->get('Myob\Custtransaction\Helper\Email')->accountPaymentMailSendMethodToCustomer($emailTemplateVariables,$senderInfo,$customerInfo);
											
										// End
											$this->messageManager->addSuccess(__('Thank you for payment for invoice. It will be update within 24-48 hours.'));
											$this->_redirect('transaction/index/index');
											return;
										}catch (\Exception $e) {
											$this->messageManager->addError(__('There has been an error processing your payment.'));			
											}	
							}
							else
							{
								$this->messageManager->addError(__('Gateway error: %1', $description));
							}
						}
						else
						{
							$this->messageManager->addError(__('There has been an error processing your payment.'));
						}
			
					}
					else
					{
						$this->messageManager->addError(__('Invalid Fields Value.'));
					}
			
		}
		catch (\Exception $e) {
			$this->messageManager->addError(__('There has been an error processing your payment.'));			
		}
		$this->_redirect('transaction/index/index');
		
        
    }   
}
