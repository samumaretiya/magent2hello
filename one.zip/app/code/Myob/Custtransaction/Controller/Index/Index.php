<?php

namespace Myob\Custtransaction\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page; 
 
class Index extends Action
{
    protected $resultPageFactory; 

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Customer\Model\Session $customerSession 
    ){
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_customerSession = $customerSession; 
    }

    public function execute()
    {         
        $resultPage = $this->resultPageFactory->create(); 
        $customer_Id = $this->_customerSession->getCustomer()->getId();
        if(!$customer_Id && $customer_Id <= 0){
            $this->_redirect('customer/account/login');
        }
        $resultPage->getConfig()->getTitle()->set(__("My Invoices"));
        return $resultPage;
    }   
}
