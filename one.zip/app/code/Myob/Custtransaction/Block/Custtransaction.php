<?php

namespace Myob\Custtransaction\Block;

use Magento\Sales\Model\Order\Address;

class Custtransaction extends \Magento\Framework\View\Element\Template 
{
    const ORDER_GRID_LIMIT = 25;

    const ORDER_DATE_FORMAT = 'd-m-Y';

	protected $_customerSession;
    
	protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    } 

    public function __construct(
    	\Magento\Catalog\Block\Product\Context $context,
    	\Magento\Customer\Model\Session $customerSession,
        \Myob\Exocustomers\Helper\Data $exoHelper,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
		\Myob\Custtransaction\Model\Custtransaction $custtransaction,
        \Magento\Customer\Block\Address\Book $addressBlock,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
    	array $data = []) 
    {
        parent::__construct($context, $data);
        $this->_customerSession = $customerSession;
        $this->_exoHelper = $exoHelper;
        $this->_priceHelper = $priceHelper;
		$this->_custtransaction = $custtransaction;
        $this->addressBlock = $addressBlock;
        $this->addressRepository = $addressRepository;
    }
    
    public function checkpaymentreceived($order_id)
	{
		if($order_id!='')
		{
			$CusttransactionCollection = $this->_custtransaction->getCollection()
						->addFieldToFilter("invoice_id", $order_id);
			return count($CusttransactionCollection);
		}
		else
		{
			return;
		}
	}
    public function getCustomerAccountNumber()
    {
		return $this->_customerSession->getCustomer()->getAccountNumber();
	} 

    public function getCustomer()
    {
        return $this->_customerSession->getCustomer();
    } 
	
    public function getlimit()
    {        
        return self::ORDER_GRID_LIMIT;
    }
	
    public function getDateFormat(){
        return self::ORDER_DATE_FORMAT;
    }

    public function formatPrice($price){
        return $this->_priceHelper->currency($price, true, false);
    }

    public function getEditUrl($order_id){
        return $this->getBaseUrl().'transaction/index/view/?trans='.$order_id;
    }

    public function getOrderGridUrl(){
        return $this->getBaseUrl().'transaction/index/index/';
    }

    public function getPrintInvoiceUrl($order_id){
       return $this->getBaseUrl().'transaction/index/invoiceprint/?trans='.$order_id; 
    }
	
	public function getPaymentUrl($order_id){
        return $this->getBaseUrl().'transaction/index/payment/?trans='.$order_id;
    }

    public function getDefaultBillingAddress(){
        $address_id = $this->getCustomer()->getDefaultBilling();
        if($address_id && $address_id >0){
            return $this->addressRepository->getById($address_id);
        }
        return;
    }

    public function getFormattedAddress($address)
    {
        return $this->addressBlock->getAddressHtml($address);
    }

    public function getOrderStatus($status){
        if($status == 'Unallocated') {
            return __('Unpaid');
        } else if($status == 'FullyAllocated') {
            return __('Paid');
        } elseif($status == 'PartlyAllocated') {
            return __('Part Paid');
        }
        return $status;
    }

    public function getBranchNameFromCode($branch_id){
        if($branch_id == 0){
            return __('TigerPak');
        }
        return __('N/A');
    }

    public function getCustomertransactionlist($offset)     
    {
        if($offset >= 1)
        {
            $page = $offset;
        }
        else
        {
            $page = 1;
        }
        $limit = $this->getlimit();
        $decoded_data = '';
        $customer_account_id = $this->getCustomerAccountNumber();
        if($customer_account_id)
        {
            $url = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&page='.$page.'&pagesize='.$limit;
            $decoded_data = $this->_exoHelper->getDataFromExo($url);         
            return $decoded_data;           
        }
        else
        {
            return;
        }        
    }
	
	public function getCustomertransactionlistsearch()     
    {       
        try
        {
            $customer_account_id = $this->getCustomerAccountNumber();
            if($customer_account_id)
            {
                            
                $url1 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=1';                       
                $decoded_data1 = $this->_exoHelper->getDataFromExo($url1);
                if(count($decoded_data1)>0)
                {
                    $decoded_data = $decoded_data1;
                }
                
                $url2 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=2';
                $decoded_data2 = $this->_exoHelper->getDataFromExo($url2);
                if(count($decoded_data2)>0)
                {
                    $decoded_data = array_merge($decoded_data,$decoded_data2);
                }
                
                $url3 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=3';
                $decoded_data3 = $this->_exoHelper->getDataFromExo($url3);
                if(count($decoded_data3)>0)
                {
                    $decoded_data = array_merge($decoded_data,$decoded_data3);
                }

                 return $decoded_data;
                
            }            
            else
            {
                return;
            }
        }
        catch(Exception $e)
        {
            return;
        }
        
    }

    public function ispagination()     
    {       
        try
        {
            $customer_account_id = $this->getCustomerAccountNumber();
            if($customer_account_id)
            {
                            
                $url1 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=1';                       
                $decoded_data1 = $this->_exoHelper->getDataFromExo($url1);
                if(count($decoded_data1)>0)
                {
                    $decoded_data = $decoded_data1;
                }
                
                $url2 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=2';
                $decoded_data2 = $this->_exoHelper->getDataFromExo($url2);
                if(count($decoded_data2)>0)
                {
                    $decoded_data = array_merge($decoded_data,$decoded_data2);
                }
                
                $url3 = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction?$orderby=InvoiceNumber%20desc&pagesize=100&page=3';
                $decoded_data3 = $this->_exoHelper->getDataFromExo($url3);
                if(count($decoded_data3)>0)
                {
                    $decoded_data = array_merge($decoded_data,$decoded_data3);
                }

                $total_rec = count($decoded_data);          
                if($total_rec > $this->getlimit())
                {
                    $pager = ceil($total_rec / $this->getlimit());
                    return $pager;
                }
                
            }            
            else
            {
                return;
            }
        }
        catch(Exception $e)
        {
            return;
        }
        
    }

    public function getTransactioncustomerdetails($trans_id)
    {
        $customer_account_id = $this->getCustomerAccountNumber();
        
        if ($trans_id && $customer_account_id) {
            try
            {
                $url = 'https://exo.api.myob.com/debtor/'.$customer_account_id.'/transaction/'.$trans_id;           
                $decoded_data = $this->_exoHelper->getDataFromExo($url);         
                return $decoded_data;
            }
            catch(Exception $e)
            {
                return;
            }
        }
    }

    /* The following function is used for back button url on view transaction */
    public function getBackUrl()
    {
        return $this->getUrl('transaction/index/index/');
    }

    /* The following function is used for back button title on view transaction */
    public function getBackTitle()
    {
        return __("Back to My Invoices");
    }
	public function isSearch($_order)
    {
		$is_search = $this->getRequest()->getParam('is_search');		
		if($is_search)
		{
			$inv_post = $this->getRequest()->getParam('invoice');
			$reference2_post = $this->getRequest()->getParam('reference2');
			
			$date_from_post = $this->getRequest()->getParam('date_from');
			$date_to_post = $this->getRequest()->getParam('date_to');
			
			$filter_from_date = date('Y-m-d', strtotime($date_from_post));
			$filter_to_date = date('Y-m-d', strtotime($date_to_post));
			
			$originalDate = explode("T00",$_order['transactiondate']);
			$newDate = date("d-m-Y", strtotime($originalDate[0]));
					
			$filter_date = date('Y-m-d', strtotime($newDate));
			
			if($inv_post !='' && strpos(strtolower($_order['id']), strtolower($inv_post)) !== false)
			{
				return true;
			}
			else if($reference2_post !='' && strpos(strtolower($_order['reference2']), strtolower($reference2_post)) !== false)
			{
				return true;
			}
			else if($date_from_post !='' && $date_to_post !='' && $filter_date >= $filter_from_date && $filter_date <= $filter_to_date)
			{
				return true;
			}
		}
		else
		{
			return false;
		}
		
	}	
		
	
	
	
}
