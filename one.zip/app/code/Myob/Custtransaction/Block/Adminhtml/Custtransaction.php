<?php

namespace Myob\Custtransaction\Block\Adminhtml;

class Custtransaction extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_custtransaction';
        $this->_blockGroup = 'Myob_Custtransaction';
        $this->_headerText = __('Account Payment');
        $this->_addButtonLabel = __('Account Payment Information'); 
        parent::_construct();
        if ($this->_isAllowedAction('Myob_Custtransaction::save')) {
            $this->buttonList->update('add', 'label', __('Add New Custtransaction Information'));
        } else {
            $this->buttonList->remove('add');
        }$this->buttonList->remove('add');
    }
    
    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
