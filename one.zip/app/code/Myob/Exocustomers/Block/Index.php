<?php
namespace Myob\Exocustomers\Block;
class Index extends \Magento\Framework\View\Element\Template
{
	
}
?>