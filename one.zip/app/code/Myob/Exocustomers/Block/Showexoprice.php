<?php
namespace Myob\Exocustomers\Block;
class Showexoprice extends \Magento\Framework\View\Element\Template
{
	
}
?>