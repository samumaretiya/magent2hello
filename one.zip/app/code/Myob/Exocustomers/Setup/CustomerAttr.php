<?php

namespace Myob\Exocustomers\Setup;

use Magento\Eav\Model\Config;
use Magento\Eav\Model\Entity\Setup\Context;
use Magento\Eav\Setup\EavSetup;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Group\CollectionFactory;

class CustomerAttr extends EavSetup {

	protected $eavConfig;

	public function __construct(
		ModuleDataSetupInterface $setup,
		Context $context,
		CacheInterface $cache,
		CollectionFactory $attrGroupCollectionFactory,
		Config $eavConfig
		) {
		$this->eavConfig = $eavConfig;
		parent :: __construct($setup, $context, $cache, $attrGroupCollectionFactory);
	} 

	public function installCustomerAttributes($customerSetup) {
		$attrArray = array(
            array('account_number','Account Number'),
            array('tp_company_name','Company Name'),
            array('default_contact_id','Default Contact ID'),
            array('primary_group_id','Primary Group Id'),
            array('primary_group_name','Primary Group Name'),
            array('secondary_group_id','Secondary Group Id'),
            array('secondary_group_name','Secondary Group Name'),
            array('sales_person_id','Sales Person Id'),
            array('sales_person_name','Sales Person Name')
            );
        $i = 120;
        foreach($attrArray as $attr){
            $customerSetup -> addAttribute(\Magento\Customer\Model\Customer::ENTITY,
                $attr[0],
                [
                'label' => $attr[1],
                'system' => 0,
                'position' => $i = $i+2,
                'sort_order' =>$i,
                'visible' =>  true,
                'note' => '', 
                'default_value' => '',
                'type' => 'varchar',             
                'input' => 'text',
                'source' => ''
                ]
                );

            $customerSetup->getEavConfig()->getAttribute('customer', $attr[0])->setData('is_user_defined',1)->setData('is_required',0)->setData('used_in_forms', ['adminhtml_customer', 'checkout_register', 'customer_account_create', 'customer_account_edit', 'adminhtml_checkout']) -> save();
        }
	} 

	
	public function getEavConfig() {
		return $this->eavConfig;
	} 
} 

