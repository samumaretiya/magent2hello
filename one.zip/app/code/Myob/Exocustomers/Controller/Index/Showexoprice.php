<?php
namespace Myob\Exocustomers\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page;

class Showexoprice extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Myob\Exocustomers\Helper\Data $exoHelper,
		\Magento\Framework\Pricing\Helper\Data $priceHelper
	)
	{
		parent::__construct($context);
		$this->_pageFactory = $pageFactory;		
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_customerSession = $customerSession;
		$this->_exoHelper = $exoHelper;
		$this->priceHelper = $priceHelper;
	}

	public function execute()
	{
		
		$results = array();
		$resultJson = $this->resultJsonFactory->create(); 
		$post 	= $this->getRequest()->getPostValue();		
		$sku 	= (int)$this->getRequest()->getPost('sku');
		$qty 	= (int)$this->getRequest()->getPost('qty');
		$original_price 	= $this->getRequest()->getPost('org_price');
		
		$account_id = $this->_customerSession->getCustomer()->getAccountNumber();
		
		if($account_id!='' && $sku!='')
		{					
					$url = 'https://exo.api.myob.com/stockitem/'.$sku.'/bestprice?debtorid='.$account_id.'&quantity='.$qty.'';		
					$decoded_data = $this->_exoHelper->getDataFromExo($url);								
					if(count($decoded_data)>0 && isset($decoded_data[0]['unitpriceafterdiscount']))
					{
							$final_new_price = $decoded_data[0]['unitpriceafterdiscount'];
							if($final_new_price > 0)
							{
									$results['new_price'] = $this->priceHelper->currency($final_new_price, true, false);
							}
							else
							{
									$results['new_price'] = $this->priceHelper->currency($original_price, true, false);
							}
					}
					else
					{
						$results['new_price'] = $this->priceHelper->currency($original_price, true, false);
					}
		}
		else
		{
			$results['new_price'] = $this->priceHelper->currency($original_price, true, false);
		}
		
		
		$results['success'] = true;
		return $resultJson->setData($results);
	}
}