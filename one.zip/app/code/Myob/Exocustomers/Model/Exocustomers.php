<?php

namespace Myob\Exocustomers\Model;

/**
 * Exocustomers Model
 *
 * @method \Myob\Exocustomers\Model\Resource\Page _getResource()
 * @method \Myob\Exocustomers\Model\Resource\Page getResource()
 */
class Exocustomers extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Myob\Exocustomers\Model\ResourceModel\Exocustomers');
    }

}
