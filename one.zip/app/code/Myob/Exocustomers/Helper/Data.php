<?php

/**
 * Exocustomers data helper
 */
namespace Myob\Exocustomers\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
   	const XML_PATH_FOR_EXO_AUTH = 'exocustomers/view/exo_authorization';

   	const XML_PATH_FOR_EXO_KEY = 'exocustomers/view/exo_myobapikey';

   	const XML_PATH_FOR_EXO_TOKEN = 'exocustomers/view/exo_myobapitoken';


   	public function __construct(
        \Magento\Framework\App\Helper\Context $context,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
        \Myob\Exoproducts\Logger\Logger $exo_logger
    ) {
    	$this->exo_logger = $exo_logger;
        parent::__construct($context);
		$this->_storeManager = $storeManager; 
		$this->_customerSession = $customerSession;
    }

    public function getExoAuthorization()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FOR_EXO_AUTH, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getExoKey()
	{
		return $this->scopeConfig->getValue(self::XML_PATH_FOR_EXO_KEY, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
	}
	
	public function getExoToken()
	{
		return $this->scopeConfig->getValue(self::XML_PATH_FOR_EXO_TOKEN, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
	}

	public function getDataFromExo($url)
	{
		try{
			$exo_authorization = $this->getExoAuthorization();
			$exo_myobapikey = $this->getExoKey();
			$exo_myobapitoken = $this->getExoToken();
			
			$header = array();
			$header[] = 'Accept: application/json';
			$header[] = 'Authorization: '.$exo_authorization.'';
			$header[] = 'x-myobapi-key: '.$exo_myobapikey.'';
			$header[] = 'x-myobapi-exotoken: '.$exo_myobapitoken.'';

			//cURL starts
			$crl = curl_init();
			curl_setopt($crl, CURLOPT_URL, $url);
			curl_setopt($crl, CURLOPT_HTTPHEADER,$header);
			curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($crl, CURLOPT_HTTPGET,true);
			$response = curl_exec($crl);

			//error handling for cURL
			if ($response === false) { 
				$this->exo_logger->addDebug('Curl return no response.');      
			   return;
			}
			curl_close($crl);   
			$decoded_data = json_decode($response, true);
			
			$record_count = count($decoded_data);
			if($record_count<1)
			{
				$this->exo_logger->addDebug('Curl return Zero record.');
				return;			
			}
			
			if($record_count>0)
			{
				return $decoded_data;
			}
		} catch (Exception $e){
			$this->exo_logger->addError('Curl Error => '.$e->getMessage());
		}		
	}
	
	public function checkisCustomerLogin()
    {
		if($this->_customerSession->isLoggedIn())
		{
			return true;	
		}
    }
	
	public function isExocustomers()
    {
			if($this->_customerSession->isLoggedIn())
			{
				$customer = $this->_customerSession->getCustomer();
				if($customer->getGroupId() == 4)
				{
					return true;
				}
			}
    }
	
	public function getExoPriceUrl()
    { 
        $storeId = $this->_storeManager->getDefaultStoreView()->getStoreId();
    	$url = $this->_storeManager->getStore($storeId)->getUrl("exocustomers/index/Showexoprice");
		return $url;
    }
	
}
