<?php
namespace Myob\Exoproducts\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class Setexoprice implements ObserverInterface
{
	 public function __construct(
    	\Magento\Customer\Model\Session $customerSession,
        \Myob\Exocustomers\Helper\Data $exoHelper)
    {
        $this->_customerSession = $customerSession;
        $this->_exoHelper = $exoHelper;        
    }
	
	public function execute(\Magento\Framework\Event\Observer $observer)
	{		
		
		$customerSessionData = $this->_customerSession;	
		if($customerSessionData->isLoggedIn())
		{
			$account_id = $customerSessionData->getCustomer()->getAccountNumber();			
			$item = $observer->getEvent()->getData('quote_item');
			$product_id = $item->getProductId();
			$sku = $item->getSku();
			$qty = $item->getQty();
			if($qty=='' || $qty==0)
			{
				$qty = 1;
			}
			
			if($account_id!='' && $sku!='')
			{
				$url = 'https://exo.api.myob.com/stockitem/'.$sku.'/bestprice?debtorid='.$account_id.'&quantity='.$qty.'';		
				$decoded_data = $this->_exoHelper->getDataFromExo($url);								
				if(count($decoded_data)>0 && isset($decoded_data[0]['unitpriceafterdiscount']))
				{
					$final_new_price = $decoded_data[0]['unitpriceafterdiscount'];
					if($final_new_price > 0)
					{
						$item->setCustomPrice($final_new_price);
						$item->setOriginalCustomPrice($final_new_price);
						$item->getProduct()->setIsSuperMode(true);
					}
				}
			}
			
					
		
		}
	}
	
}