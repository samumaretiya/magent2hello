<?php

namespace Myob\Exoproducts\Model;

/**
 * Exoproducts Model
 *
 * @method \Myob\Exoproducts\Model\Resource\Page _getResource()
 * @method \Myob\Exoproducts\Model\Resource\Page getResource()
 */
class Exoproducts extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Myob\Exoproducts\Model\ResourceModel\Exoproducts');
    }

}
