<?php
namespace Myob\Exoproducts\Logger;

class Logger extends \Monolog\Logger
{

}