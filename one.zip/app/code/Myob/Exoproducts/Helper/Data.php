<?php
/**
 * Exoproducts data helper
 */
namespace Myob\Exoproducts\Helper;
use Magento\Framework\App\Filesystem\DirectoryList;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
}
