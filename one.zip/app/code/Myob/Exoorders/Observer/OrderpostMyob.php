<?php
namespace Myob\Exoorders\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class OrderpostMyob implements ObserverInterface
{ 
    protected $orderRepository;

    public function __construct(  
		OrderRepositoryInterface $OrderRepositoryInterface,
		\Myob\Exoorders\Helper\Data $myob_helper,
		\Myob\Exocustomers\Helper\Data $myob_customershelper,		
	    \Magento\Customer\Model\Customer $customer

    ) {
        $this->orderRepository = $OrderRepositoryInterface;
		$this->myob_helper = $myob_helper;
		$this->myob_customershelper = $myob_customershelper;
	    $this->_customer = $customer;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
		//Custom log:
		$writer = new \Zend\Log\Writer\Stream(BP.'/var/log/testorder.log');
		$logger = new \Zend\Log\Logger();
		$logger->addWriter($writer);
		$order_ids = $observer->getEvent()->getOrderIds()[0];
		$order = $this->orderRepository->get($order_ids);
		$order_id = $order->getIncrementId();
		
		// New Data
		$pickup = 'N';
		$delivered = 'N';
		$defaultlocationid = 1;
		$delivered = 'Y';
		$customer_id = $order->getCustomerId();
		
		$customer = $this->_customer->load($customer_id);		
		$company = $customer->getTpCompanyName();		
		$customer_code = $customer->getAccountNumber();
		$debtor_id = $customer->getAccountNumber();
		$group_id = $customer->getGroupId();
		$customer_sales_person_id = $customer->getSalesPersonId();		
		
		$exo_authorization = $this->myob_customershelper->getExoAuthorization();
		$exo_myobapikey = $this->myob_customershelper->getExoKey();
		$exo_myobapitoken = $this->myob_customershelper->getExoToken();
		
		if($debtor_id!='') //// For EXO Customers....
		{
			$validate_array = json_encode(
				array(
					'debtorid' => $debtor_id,
					'status' => 'Notprocessed',
				)
			);
			
			$url = 'https://exo.api.myob.com/salesorder/validate/'; 
			$headr = array();
			$headr[] = 'Accept: application/json';
			$headr[] = 'Content-Type: application/json';
			$headr[] = 'Authorization: '.$exo_authorization.'';
			$headr[] = 'x-myobapi-key: '.$exo_myobapikey.'';
			$headr[] = 'x-myobapi-exotoken: '.$exo_myobapitoken.'';
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headr);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$validate_array);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			//echo '<pre>';print_r($server_output);
			$obj = json_decode($server_output, true);

			$validate_id = $obj['order']['id'];
			$validate_href = $obj['order']['href'];
			
			if($validate_id!='' && $validate_href!='') 
			{
				
				// Shipping Data
				$shippingAddress = $order->getShippingAddress();
				$shipping_street = $shippingAddress->getStreet()[0].' '.$shippingAddress->getStreet()[1];
				$shipping_city = $shippingAddress->getCity();
				$shipping_country = $shippingAddress->getCountry();
				$shipping_region = $shippingAddress->getRegion();
				$shipping_postcode = $shippingAddress->getPostcode();
				
				$order_date = date('Y/m/d', strtotime($order->getCreatedAt()));					
				$order_sub_total = $order->getSubtotal();
				$order_ship_amount = $order->getShippingAmount();
				$order_discount_amount = $order->getDiscountAmount();
				$order_tax_total = $order->getTaxAmount();
				$order_grand_total = $order->getGrandTotal();
				
				$duedate_final = '';
				$ext_site_contact = '';
				$ext_phone = '';
				$ext_job_reference = '';
				$ext_ship_comment = '';
				$ext_po_number = '';
				$ext_delivery_time = '';
				
				if($order->getShipDueDate()!='')
				{
					$duedate = explode("/",$order->getShipDueDate());
					$duedate_final = $duedate[2].'-'.$duedate[1].'-'.$duedate[0];
				}
				if($order->getShipPoNumber()!='')
				{
					$ext_po_number = substr($order->getShipPoNumber(),0,28);
				}
				if($order->getShipComment()!='')
				{
					$ext_ship_comment = substr($order->getShipComment(),0,28);
				}
				
				$ext_site_contact = 'Test-ship_site_contact';
				$ext_phone = 'Test-000023456';
				$ext_job_reference = 'Test-ship-job-reference';
				$ext_delivery_time = 'Test-ship-delivery-time';
				
				/*if($order->getShipSiteContact()!='')
				{
					$ext_site_contact = substr($order->getShipSiteContact(),0,28);
				}
				if($order->getShipPhoneNumber()!='')
				{
					$ext_phone = substr($order->getShipPhoneNumber(),0,18);
				}
				if($order->getShipJobReference()!='')
				{
					$ext_job_reference = substr($order->getShipJobReference(),0,28);
				}
				
				if($order->getShipDeliveryTime()!='')
				{
					$ext_delivery_time = $order->getShipDeliveryTime();
				}*/
				
				foreach ($order->getAllVisibleItems() as $key => $value){
					$item_data[] = array(
						'stockcode'=>$value->getSku(),
						'isoriginatedfromtemplate'=> false,
						'orderquantity'=>$value->getQtyOrdered(),
						'discount'=> 0,
						'unitprice'=> $value->getPrice(),
						'ispriceoverridden'=>false,
						'locationid' => 1,
						'taxrateid' => 10,
						'listprice' => $value->getPrice(),
						'pricepolicyid'=> 0,
						'linetype' => 0,
						'uninvoicedquantity' => 0,
						'releasequantity' => 0,
						'releasenowquantity' => 1,
						'lastreleasedquantity' => 0,
						'pickedquantity' => 0,
						'picknowquantity' => 0,
						'lastpickedquantity' => 0,
						'stocktype' => 'LookupItem',
						'branchid' => 0,
						'taxratevalue' => 10,
						'istaxoverridden' => false,
						'taxoverridevalue' => 0,
						'narrative' => '',
						'backorderquantity' => 0,		
						'description'=>$value->getName(),
						'batchcode' => '',
						'duedate' => $duedate_final,
						'linetotal' => $value->getRowTotal(),
						'invoicedquantity' => 0,
						'invoicenowquantity' => 0,
						'lastinvoicedquantity' => 0,
						'suppliedquantity' => 0,
						'supplynowquantity' => 0,
						'lastsuppliedquantity' => 0,
						'restrictedline' => false,
						'rankorder' => 1,
						'extrafields' => array(
											array('key' => 'X_UPSELL', 'value' => null),
											array('key' => 'X_UPSELL_QTY', 'value' => null)
										),
						);
					}
					
					$item_data[] = array(
						'stockcode'=>'F1o',
						'isoriginatedfromtemplate'=> false,
						'orderquantity'=>1,
						'discount'=> 0,
						'unitprice'=> $order->getShippingAmount(),
						'ispriceoverridden'=>false,
						'locationid' => 1,
						'taxrateid' => 10,
						'listprice' => $order->getShippingAmount(),
						'pricepolicyid'=> 0,
						'linetype' => 0,
						'uninvoicedquantity' => 0,
						'releasequantity' => 0,
						'releasenowquantity' => 1,
						'lastreleasedquantity' => 0,
						'pickedquantity' => 0,
						'picknowquantity' => 0,
						'lastpickedquantity' => 0,
						'stocktype' => 'LookupItem',
						'branchid' => 0,
						'taxratevalue' => 10,
						'istaxoverridden' => false,
						'taxoverridevalue' => 0,
						'narrative' => '',
						'backorderquantity' => 0,		
						'description'=>'Online Freight',
						'batchcode' => '',
						'duedate' => $duedate_final,
						'linetotal' => $order->getShippingAmount(),
						'invoicedquantity' => 0,
						'invoicenowquantity' => 0,
						'lastinvoicedquantity' => 0,
						'suppliedquantity' => 0,
						'supplynowquantity' => 0,
						'lastsuppliedquantity' => 0,
						'restrictedline' => false,
						'rankorder' => 1,
						'extrafields' => array(
											array('key' => 'X_UPSELL', 'value' => null),
											array('key' => 'X_UPSELL_QTY', 'value' => null)
										),
					);
				
					$order_data_sendexo = json_encode(
						array(
							'debtorid' => $debtor_id,
							'lines' => $item_data,	
							'taxrounding'=> 0,
							'deliverycount'=> 0,
							'invoicecount'=> 0,
							'pickedcount'=> 0,
							'releasecount'=> 0,
							'hasuninvoiced'=> true,
							'hasunpicked'=> true,
							'hasunreleased'=> true,
							'hasunsupplied'=> true,
							'allowcustomerordernumber'=> false,
							'customerordernumber'=> $ext_po_number,
							'accountname' => $order->getCustomerFirstname().' '.$order->getCustomerLastname(),
							'istaxinclusive'=> false,
							'hasbackexoorders'=> true,
							'branchid'=> 5,
							'defaultlocationid'=> $defaultlocationid,
							'narrative'=> $ext_ship_comment,
							'currencyid'=> 0,
							'contactid'=> -1,
							'salespersonid'=> 4459,  /// WEB API ...
							'exchangerate'=> 1,
							'taxtotal'=> $order_tax_total,
							'subtotal'=> $order_sub_total,
							'reference'=> $ext_job_reference.'-'.$order_id,
							'instructions'=> $ext_ship_comment,
							'createdate'=> $order_date,
							'orderdate'=> $order_date,
							'duedate'=> $duedate_final,
							'finalisationdate'=> null,
							'activationdate'=> $order_date,
							'deliveryaddress' => array(
								'line1' => substr($company,0,28),
								'line2' => substr($shipping_street,0,28),
								'line3' => substr($shipping_city,0,28),
								'line4' => substr($shipping_postcode,0,28),
								'line5' => substr($shipping_country,0,28),
								'line6' => '',
							),
							'status'=> 0,
							'statusdescription'=> 'Backorder',
							'finalised'=> 0,
							'ordertotal'=> $order_grand_total,
							'localvalue'=> $order_grand_total,
							'hasrestrictedline'=> false,
							'lastupdated'=> null,
							'extrafields'=> array(
								array('key' => 'X_ORDER_BY', 'value' => substr($order->getCustomerFirstname().' '.$order->getCustomerLastname(),0,28)),
								array('key' => 'X_REQ_TIME', 'value' => $ext_delivery_time),
								array('key' => 'X_ORDER_TIME', 'value' => null),
								array('key' => 'X_SITE_CONTACT', 'value' => $ext_site_contact),
								array('key' => 'X_PHONE', 'value' => $ext_phone),
								array('key' => 'X_Order_DateTime', 'value' => $order_date),
								array('key' => 'X_DELIVER', 'value' => $delivered),
								array('key' => 'X_AD_QUOTE_EMAIL', 'value' => ''),
								array('key' => 'X_DESPATCHED_BY', 'value' => null),
								array('key' => 'X_PICKUP', 'value' => $pickup),
								array('key' => 'X_PICKED_BY', 'value' => null),
								array('key' => 'X_TEST_CHECKED_BY', 'value' => null),
								array('key' => 'X_ORDER_READ_BACK', 'value' => 'Y'),
								array('key' => 'X_NONSTK_PRODUCT', 'value' => null),
								array('key' => 'X_QUOTEDSALESPERSON', 'value' => null),
								array('key' => 'X_SEND_SMS_SITECONTACT', 'value' => 'Y'),
								array('key' => 'X_SMS_SENT', 'value' => 'N'),
								array('key' => 'X_MARGIN_PERC_FN', 'value' => null),
								array('key' => 'X_MARGIN_VALUE_FN', 'value' => null),
								array('key' => 'X_ZONE', 'value' => null),
								array('key' => 'X_SPECIAL_ORD_NOT', 'value' => null)
							),
							'id'=>$validate_id,
							'href'=>$validate_href,
						)
					);
				
					/*echo '<pre>'; print_r($order_data_sendexo); echo '</pre>';			
					exit;
				
					$odr_url = 'https://exo.api.myob.com/salesorder/'; 
					$odr_headr = array();
					$odr_headr[] = 'Accept: application/json';
					$odr_headr[] = 'Content-Type: application/json';
					$odr_headr[] = 'Authorization: '.$exo_authorization.'';
					$odr_headr[] = 'x-myobapi-key: '.$exo_myobapikey.'';
					$odr_headr[] = 'x-myobapi-exotoken: '.$exo_myobapitoken.'';
				
					$odr_ch = curl_init();
					curl_setopt($odr_ch, CURLOPT_URL,$odr_url);
					curl_setopt($odr_ch, CURLOPT_HTTPHEADER, $odr_headr);
					curl_setopt($odr_ch, CURLOPT_POST, 1);
					curl_setopt($odr_ch, CURLOPT_POSTFIELDS,$order_data_sendexo);
					curl_setopt($odr_ch, CURLOPT_RETURNTRANSFER, true);
					$odr_output = curl_exec ($odr_ch);
					curl_close ($odr_ch);
					*/
				}
			}		
			
    	}
	}