<?php

/**
 * Exoorders data helper
 */
namespace Myob\Exoorders\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
   
}
