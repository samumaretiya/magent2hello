# Digital Pianism Reindex

A small module to be able to reindex Magento 2 from the backend

## How to

Go to System > Index Management.

Select the indexes you want to reindex.

Choose Reindex in the mass actions list.

Click Submit.

Enjoy



