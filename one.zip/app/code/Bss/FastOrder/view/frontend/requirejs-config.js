var config = {
    map: {
        '*': {
            'bss/fastorder': 'Bss_FastOrder/js/fastorder',
            'bss/fastorder_option': 'Bss_FastOrder/js/select-option',
            'bss/fastorder_swatch': 'Bss_FastOrder/js/fastorder-swatch',
            'bss/fastorder_downloadable': 'Bss_FastOrder/js/downloadable',
            'bss/fastorder_grouped': 'Bss_FastOrder/js/grouped',
            'Magento_Catalog/js/price-box':'Bss_FastOrder/js/custompricebox',
            'priceOptions' : 'Bss_FastOrder/js/price-options'
        }
    }
};
