var config = {
    "map": {
        "*": {
            "menu": "js/menu"
        }
 
    }
};
